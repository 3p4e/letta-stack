# Purely Plant — QC package, 2026-09-16 — workbook v39 (no PDFs)

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

The four compiled tranche PDFs are **not** in this archive — they come to
104 MiB together. Every certificate is still here as HTML, individually
under `certificates/individual/` and as two scrollable sets. The PDFs
download on their own from `deliverables/qc_gap_analysis/drafts/` in the
repository.

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_BG1024_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_BSS1024_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_GG1024_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_HPA1024_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_OPM1024_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050022_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050042_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050072_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050082_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050192_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050212_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050222_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050312_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060022_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060072_reissue.html` | 79.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060112_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060122_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060132_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060182_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060232_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060282_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060322_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060332_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060352_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060362_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060372_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060382_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060412_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060422_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060492_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 18.1 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 853.7 KiB | All 22 release certificates as one scrollable page |
| `certificates/Tranche_1_2_CoQ_Reissue_Draft_Set.html` | 1.9 MiB | Every reissue as one scrollable page |
| `compilation/CoQ_compilation_v39.xlsx` | 420.3 KiB | The owner's first request: one row per certificate of quality, and for every determination #1 to #12 the result, the document, its date of issue and its laboratory |
| `compilation/CoQ_compilation_v39_wide.csv` | 324.8 KiB | The same table, one row per certificate |
| `compilation/CoQ_compilation_v39_long.csv` | 1.1 MiB | The same table, one row per certificate AND determination, with the method, the acceptance criterion, the sample receipt date, the status and the route |
| `references/CoQ_references_v39.xlsx` | 34.8 KiB | One row per certificate, one column per determination — the document each rests on |
| `references/CoQ_references_v39.csv` | 77.7 KiB | The same, flat |
| `references/CoQ_references_v39.md` | 83.9 KiB | The same, readable |
| `references/CoQ_references_v39_nt.md` | 26.5 KiB | Every cell that reads 'not tested', for review |
| `workbook/CoQ_Analysis_Master_v39.xlsx` | 779.0 KiB | The desk workbook — coverage, registers with the 10-11.09 issue dates, Reconciliation 09.09 |
| `desk/qc_quality_desk_artifact.html` | 3.1 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 21.7 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/batch_dates_2026-09-10.csv` | 5.4 KiB | Harvest and packaging windows per batch — where the internal CoA's testing dates come from |
| `sources/icoa_register_2026-09-10.csv` | 24.7 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 25.0 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 8.0 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/OPEN_ITEMS.md` | 62.5 KiB | Everything still the owner's to decide — what was found, what the desk did, what is being asked, and the evidence behind each |
| `docs/RESULT_SUPERSESSION_2026-09-16.md` | 15.0 KiB | Does any certificate print a result the record has replaced? The sweep over all seventeen determinations — READ THE COVERAGE TABLE FIRST: no lot on file carries a second heavy-metal certificate, so #11 could not be compared at all |
| `tables/Batch_Parameter_Sources_v39.xlsx` | 273.4 KiB | Asked for on 16.09.2026: one row per batch, one column per determination #1 to #12, and in the cell the document that certifies it with its date of issue — [internal] where the citation is the company's own certificate of analysis, and both the release and the reissue citation where they differ. Second sheet: the same one row per batch, certificate and determination |
| `tables/Batch_Parameter_Sources_v39.csv` | 152.2 KiB | The same table as text, one row per batch |
| `tables/Batch_Parameter_Sources_v39_long.csv` | 766.0 KiB | The same table, one row per batch, certificate and determination |
| `docs/FLEET_FINDINGS_2026-09-16.md` | 11.9 KiB | What twelve agents found reading the primary records on 16.09.2026, sorted into defect (fixed, or named as not fixed and why), question for the owner, and no action — including two claims that did not survive checking |
| `docs/HANDOVER_RESPONSE_2026-09-16.md` | 13.0 KiB | The parallel desk's audit of the 127 rendered certificates, answered finding by finding — four refuted with the comparison counted, three confirmed |
| `docs/TRUTH_CHECK_2026-09-15.md` | 8.5 KiB | Every parameter result and every cited document checked from the primary records forward, by a code path that imports none of the builders |
| `docs/VOCABULARY_2026-09-11.md` | 95.1 KiB | The 11.09 audit of parameter values and references: one spelling per assertion, and the laboratory verdict the desk could not read |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 18.8 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 31.5 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
31754e2fd6a433d613e20842350e901bcc26b5287940baee082aa1da0992b0b2  certificates/individual/DRAFT_CoQ_BG1024_reissue.html
b9714a5651e07a8f06d59e6f47e434b9ba2f487f9c0b40a4eb53ffb437a063ff  certificates/individual/DRAFT_CoQ_BSS1024_reissue.html
2e2488a5e7c75e093c9214b4c7ecbf111e757d459491101be41c97e6c6c8a112  certificates/individual/DRAFT_CoQ_GG1024_reissue.html
a10788e1335c1f65a342c9a55912262a08375edbb96a911b6ce65c86f8602c0d  certificates/individual/DRAFT_CoQ_HPA1024_reissue.html
5af2102a20dfb88299adabc58745f83d02f757771e2a5ea95d9817a462ddbd6e  certificates/individual/DRAFT_CoQ_OPM1024_reissue.html
78b1ab3c1d17934ed12e7ff32fa39189de4530ce4dd77b7b485694e7c37f635b  certificates/individual/DRAFT_CoQ_P050022.html
159b25a8dad91ac605793c295b3778665da52b1e4d9ddd3e5cbc8de2fa749070  certificates/individual/DRAFT_CoQ_P050022_reissue.html
f1783fd70327c7d6594576d9521c4fa9c0ae148ad1d557eb1eaf26cf03664994  certificates/individual/DRAFT_CoQ_P050042_reissue.html
ef2d522b3afb61058c9afeeb1383b798e3629872c19406e5929e0db3770e97db  certificates/individual/DRAFT_CoQ_P050052.html
bafd77eb4ff69d5c54142aa6602f70652be52d850bbb675d1c593b44998b8e6a  certificates/individual/DRAFT_CoQ_P050052_reissue.html
f1dff42d68e130ae4e9b1b7273b0da72fb9ba12f78c616587e5009205785463c  certificates/individual/DRAFT_CoQ_P050062.html
d843a6df87b6807a128d48dac9e7fa4b4c4ec0ff15e286bf3e59b7b44339d0fb  certificates/individual/DRAFT_CoQ_P050062_reissue.html
eab7fae9954ce03099ca1de44c745dbc6b688be156eb73c14502c6f276533b9b  certificates/individual/DRAFT_CoQ_P050072_reissue.html
0ca4d773695de008c49e97e28044e3541d3bafd84da279b568969b3d98dbef80  certificates/individual/DRAFT_CoQ_P050082_reissue.html
d50753c96d03f3ab4ff81af436f3288af1d3f0dcd448ce5e99bd197635641190  certificates/individual/DRAFT_CoQ_P050092.html
c23fd5e2c7941dc8eb9789f55657148ced32485b1659976ce706a53f8b867910  certificates/individual/DRAFT_CoQ_P050092_reissue.html
dbb94f7c4c0e96cc887c7c789d462443498b44421cf6736a24edd4d27a7f3cc4  certificates/individual/DRAFT_CoQ_P050112.html
11f0b3b22db90a9773b214f1361632e6b619fa391ffb0b9230d3a53faea38ff9  certificates/individual/DRAFT_CoQ_P050112_reissue.html
15093106c9a3f27d435fb7d2c4845cafeb786e2a79e35ad5b5b12ec4fa2cb171  certificates/individual/DRAFT_CoQ_P050152.html
6fd4123a1948fbc4b736b9600054d7e8ad5eb81cbbfb4ed2a0167ddb17dcf9c7  certificates/individual/DRAFT_CoQ_P050152_reissue.html
de5245a53b00068ff55aed9b1f8c858d7da413ec93522eaf00449a02e7379e20  certificates/individual/DRAFT_CoQ_P050162.html
8cdc57f58e2300218a87e8259cc0c06e5bf8bd72b1489d807ddded6ea01a966d  certificates/individual/DRAFT_CoQ_P050162_reissue.html
f00fcf664c87639cac0a6c110acf1265cfb52e24bbbd24b77d9b3b2a60ec56c5  certificates/individual/DRAFT_CoQ_P050182.html
0bac95f5b7e593d4460c32ca0ae615c5df6efb8219d0489ca23744451db4f8c3  certificates/individual/DRAFT_CoQ_P050182_reissue.html
7b08ec44d0cc55b16fd86332a52d57d07718c86192beb49bfb92009f8ac616b8  certificates/individual/DRAFT_CoQ_P050192_reissue.html
723d485e1ba8617d14e4ac2af94daa2984de2ed841e59ab5eec03398cc84283b  certificates/individual/DRAFT_CoQ_P050212_reissue.html
801b1eb296edf429d7eb1297cc7b33881a42a0a7440f18331d22fa3349ab2d62  certificates/individual/DRAFT_CoQ_P050222_reissue.html
958a5fdb91a990ab06ae9cc8238a6bff9ed04ed95096ceba30e3375f09b83ed1  certificates/individual/DRAFT_CoQ_P050282.html
efd9e465cd7d208fb1c465b9033edc26fc9fd4ab302280b0a7cfc0307916c5ad  certificates/individual/DRAFT_CoQ_P050282_reissue.html
b3912cd1c2d0ef3d37f61071563f0b43881260915efd6fcdc6ae33b2ea8ec871  certificates/individual/DRAFT_CoQ_P050302.html
2190ac48d1aed474fef8b1dda5c215d30dc4904db332606c922424541f51dfdb  certificates/individual/DRAFT_CoQ_P050302_reissue.html
d2f852392cf4b6cda1c6ebc58abf729f6a60413c6975c2855e05bcc7f12fd090  certificates/individual/DRAFT_CoQ_P050312_reissue.html
2a3758b2120a1fe1269647bceb622bfe03c35e487bac1b3d466d31b364a04084  certificates/individual/DRAFT_CoQ_P050322.html
e45fe35b919f8aacad6ffc7a95d6ad84c0a433af6b1ecf9ac49d587cd192674e  certificates/individual/DRAFT_CoQ_P050322_reissue.html
a6ce47c3d410e57a031c477cdee2af1dbf967935606ac0aab583a2c48f6afe12  certificates/individual/DRAFT_CoQ_P060012.html
f19f4d2dad818b31b3b8b5bcd3ee28e08e81e0069b2a7724b345e8f160beab4f  certificates/individual/DRAFT_CoQ_P060012_reissue.html
5b9947ae3978d652c8696610595e2ce6be9024cb3a4004b8fa29a5179e03aafa  certificates/individual/DRAFT_CoQ_P060022_reissue.html
9ba10f25f54a3e45b24a5ba43a06ea21fa2ee4c94f3c514c5bebf08535dda296  certificates/individual/DRAFT_CoQ_P060032.html
eef078ed37225e8185accba4b8bf9653cc4dffd424b474454157f2b88868eb02  certificates/individual/DRAFT_CoQ_P060032_reissue.html
1e80b083d71c207b789b861d13858b4a0e0e82f8c496dcf8bb0e4e968152134e  certificates/individual/DRAFT_CoQ_P060042.html
e8000d6c377f86e0d4906de93b4f5d7785fccdc852a7a904755bd5169a7728cd  certificates/individual/DRAFT_CoQ_P060042_reissue.html
3e78592ebe33890fc0582604e74b527e661fc71d5e95b77a8d4e18b4d157dcf3  certificates/individual/DRAFT_CoQ_P060062.html
be24909d0dd1cc25288e674d550483e01e125480822e92ce10dcf4093e0ae27e  certificates/individual/DRAFT_CoQ_P060062_reissue.html
a220dc9cf495a03a9efcab0c6ae91a52eab8c9fc16812462e9052791b0fa2e8b  certificates/individual/DRAFT_CoQ_P060072_reissue.html
136f55977e39d053e6a81df10955b5073d6f93b6c02e17e1639818174566eaa1  certificates/individual/DRAFT_CoQ_P060082.html
d113dea7b1292f13f12eb25dd5aa70048fd0b23804d8545f9a2f33d3d77ef969  certificates/individual/DRAFT_CoQ_P060082_reissue.html
cffe09e04f965fb469680cf9470ba2629702b8679801e980cbe895cb03fdc04d  certificates/individual/DRAFT_CoQ_P060092.html
838b0e104c2fd0e4cccccce352915da09d1442160ad40a301ea43ac6a66eb75c  certificates/individual/DRAFT_CoQ_P060092_reissue.html
b0364082cca1c96f36cbbfd2b606e22ef03b9ecc3baa958f78603aea36d2ccdc  certificates/individual/DRAFT_CoQ_P060112_reissue.html
b5ac3b6e72ec87390fc07c7478067c97d5316406e710e2d19ef53ea1d47e6c84  certificates/individual/DRAFT_CoQ_P060122_reissue.html
103f85a08bdf65f64065d13456933e1bd726c9a4a2d9c558f0cd0784898ad262  certificates/individual/DRAFT_CoQ_P060132_reissue.html
81598bc87bb4e028fd214f42318a52aed47bbef1979fcd1ae346fb3003047594  certificates/individual/DRAFT_CoQ_P060152.html
c16a9fb867e2762d6879676593ae8c4f3fb983394a0cfceaeb4b8fe0cd27ed26  certificates/individual/DRAFT_CoQ_P060152_reissue.html
24188c51931c2cbb2c021b3099072dc026850260f44b0f36b24357cd235094a6  certificates/individual/DRAFT_CoQ_P060172.html
f3c78e3805359400ee8ac326776b9e3e91955a1922f4b457220a8693f359ea04  certificates/individual/DRAFT_CoQ_P060172_reissue.html
f4d30ec97ec2ca4ca483804fe9b1d87ad2b39fd05b1af95ca9f19ed751b4c604  certificates/individual/DRAFT_CoQ_P060182_reissue.html
c6fa9f8579651e23e28618abd7a72e5db975be189bbe0e6fc3a33d555206a3cf  certificates/individual/DRAFT_CoQ_P060212.html
beb88c2f1d86f8cfa26db3832712001757c301c8af0aa487d7f99c08c37f0cfb  certificates/individual/DRAFT_CoQ_P060212_reissue.html
e1b4921de8a8375d23c58487313aecc526fc980dbee9fa437763016e2bb8dc3b  certificates/individual/DRAFT_CoQ_P060232_reissue.html
a1e0bba3762d3275ef58df1efe292b5741985bc477f50495b433a92b194851ae  certificates/individual/DRAFT_CoQ_P060242.html
190a4936fdf6a0203ea36ca50cd743505ebc1e1d447335d1998b281fd3216eef  certificates/individual/DRAFT_CoQ_P060242_reissue.html
76e83fcb8626cb780a861b021b10e0b794ddef82d1cebc142e476b62e601fc40  certificates/individual/DRAFT_CoQ_P060282_reissue.html
c37e1bfd2479f0f0e749c70fed295a4376cfe24468146012290399f8894d0c86  certificates/individual/DRAFT_CoQ_P060322_reissue.html
35a2824c73d71236a8411a3a379684b1010f7c0628d2813c4463c2f3ac4438db  certificates/individual/DRAFT_CoQ_P060332_reissue.html
bde86182285ad99ceff9a12c8cf6cf5d069436ac473bec1461994075a22f4be2  certificates/individual/DRAFT_CoQ_P060352_reissue.html
e73d71818529e7577f60e5c913e361f5a558ddb55d4a8c3afae1aea1b2071fc6  certificates/individual/DRAFT_CoQ_P060362_reissue.html
79cf69a338fab55587bab77295b2d256cacf940b0479c1ae413557007dcc1d70  certificates/individual/DRAFT_CoQ_P060372_reissue.html
37f4ad204b0a11aa5d2ed65851f5a8513682f2f14451b3fc6549fcd3901194d3  certificates/individual/DRAFT_CoQ_P060382_reissue.html
aa4e90379c64524c368a0acf0b16dca789e0daac4928e6b2cfdd282684f44dc7  certificates/individual/DRAFT_CoQ_P060402.html
95f8948155b142b963a433992c206287ca2e4bdb983f7d9650cc75c58c547c26  certificates/individual/DRAFT_CoQ_P060402_reissue.html
d31a6891eb1c425fb97f68a370387e0dc66c093634ab38b24834ff62705348c6  certificates/individual/DRAFT_CoQ_P060412_reissue.html
ca0ff3e5a14c05f95aa85ec930fbba9b5cfb8f3dc9cef55d273b861e94595f1a  certificates/individual/DRAFT_CoQ_P060422_reissue.html
c2c6cfb6777d9e2c066d1bbb82602f7310d754b6419e2309c23fc658a220c932  certificates/individual/DRAFT_CoQ_P060492_reissue.html
e396d0e21fe89a186e879f11a0d8267940a6316b3a855903114856b3c47b002a  INDEX.html
6e074b837e6c4fe4e27ba1c1327c8840220ef8619b16e7a931814813ea75db7c  certificates/Tranche_1_2_CoQ_Draft_Set.html
07467fa44bad9846f6789736ad53b2917f7dbc34251deb3dfd2972f5cf7ced12  certificates/Tranche_1_2_CoQ_Reissue_Draft_Set.html
84220c5ce53307c9b69fd88a8f039d43d5766877eda880661958f013b87c1e14  compilation/CoQ_compilation_v39.xlsx
bbe1b23d1ad50175a34265844535148d758495e0b70811e5392692cfdeb95faa  compilation/CoQ_compilation_v39_wide.csv
dcb0d3b5a38f15713c43728605e7e391b34388731d9398b6ecec4aea55f4c7ea  compilation/CoQ_compilation_v39_long.csv
328aa584a29998661c02d85bad8bff9f9f91666c6b2f62acad168384d554e7e4  references/CoQ_references_v39.xlsx
65dca0a15b0485cc6a57b00f48d22a8095d76611444f002872fcd3d1f013f568  references/CoQ_references_v39.csv
52b55f51a7afc8432b3d77bbdfa8855cd097d9e896ff8daf76aef787805dec61  references/CoQ_references_v39.md
5e6d79406f3df5a95e8d7676ba3643659fd677ece6d1d4f497503b897fee177b  references/CoQ_references_v39_nt.md
8ca0708064c61f7249b79d16ff828945c78176c1496f59656dc3a189d2f3f824  workbook/CoQ_Analysis_Master_v39.xlsx
664564ef93002641011aa76f2f290ff93bdcf320387445ae80375b1171679179  desk/qc_quality_desk_artifact.html
1e41cc9d9970abf09b8ebde266bd7dd133fb837b6afd1eb0414fc22754ac5fa5  sources/issuance_schedule_2026-09-10.csv
22f2e9cc57bdbc1fab4a8ee8cc3146d34ee647515a5e294a9781526f79f047f9  sources/batch_dates_2026-09-10.csv
b7231261c4dfdbffa67f15140abc0b0da53f585b9f38cedb0adee3be60bb0c88  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
24db49e05f5e936614da919ec0433b63e6069321bb5fb91aeb7ec26fcbff3dd9  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
690bb197ce43997a96e8d5c23d23e5f9c90af986e1e8d097b30f9e19e41bab11  sources/coq_draft_gaps.csv
e63b6d0506d89fe7b3896b3c93914fdf13fac987b2bf37682dc40235067fd917  docs/OPEN_ITEMS.md
548279a2d9a9dc10dc9ab701b15b150ff9373d4a99f4728de864496f66f3b3c9  docs/RESULT_SUPERSESSION_2026-09-16.md
0579ff1e1288d9857c06f2be9586080e8042de0bbda1a7064d591e2b9673d1ca  tables/Batch_Parameter_Sources_v39.xlsx
e30a03c69846ab72bfef31b5dd3a2a1e25f9ca1c7bb386c61b17df6d66da6936  tables/Batch_Parameter_Sources_v39.csv
32ffdc6cda025e3c2f4c69fdaa45f001434c24e58b9d3efbcf26f1b5b7c0aff3  tables/Batch_Parameter_Sources_v39_long.csv
96555e37373ee61fb01436456369f203b93d8e7eb746280f0e9063b3d3375ec5  docs/FLEET_FINDINGS_2026-09-16.md
f7315cbf159508aaf14c125324313e970fb7d7308364630e0ce9df67a59c3498  docs/HANDOVER_RESPONSE_2026-09-16.md
c11d1a356842123401d6829476dd894ad6dfba1eb53f19a9038eb446c568346e  docs/TRUTH_CHECK_2026-09-15.md
512c8fca43e11b78338c89dad51fc1f9475ec7146022d480ce8929a9fb31e814  docs/VOCABULARY_2026-09-11.md
2f86d9e6ae5800af08077c3a90d659b71e9758cfdd75a59f0511669a2ce2b7e8  docs/ISSUANCE_RULES_2026-09-10.md
101232cbe02dabe959f4ac14e3f9bdd773bfa6ff42bf2172d41b88389a7f157f  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
