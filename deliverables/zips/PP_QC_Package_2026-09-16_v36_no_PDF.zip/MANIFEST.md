# Purely Plant — QC package, 2026-09-16 — workbook v36 (no PDFs)

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

The four compiled tranche PDFs are **not** in this archive — they come to
104 MiB together. Every certificate is still here as HTML, individually
under `certificates/individual/` and as two scrollable sets. The PDFs
download on their own from `deliverables/qc_gap_analysis/drafts/` in the
repository.

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_BG1024_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_BSS1024_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_GG1024_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_HPA1024_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_OPM1024_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050022_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050042_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050072_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050082_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050192_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050212_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050222_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050312_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060022_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060072_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060112_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060122_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060132_reissue.html` | 78.9 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060182_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060232_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060282_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060322_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060332_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060352_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060362_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060372_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060382_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060412_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060422_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060492_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 18.1 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 860.7 KiB | All 22 release certificates as one scrollable page |
| `certificates/Tranche_1_2_CoQ_Reissue_Draft_Set.html` | 1.9 MiB | Every reissue as one scrollable page |
| `compilation/CoQ_compilation_v36.xlsx` | 418.7 KiB | The owner's first request: one row per certificate of quality, and for every determination #1 to #12 the result, the document, its date of issue and its laboratory |
| `compilation/CoQ_compilation_v36_wide.csv` | 321.4 KiB | The same table, one row per certificate |
| `compilation/CoQ_compilation_v36_long.csv` | 1.1 MiB | The same table, one row per certificate AND determination, with the method, the acceptance criterion, the sample receipt date, the status and the route |
| `references/CoQ_references_v36.xlsx` | 35.4 KiB | One row per certificate, one column per determination — the document each rests on |
| `references/CoQ_references_v36.csv` | 76.0 KiB | The same, flat |
| `references/CoQ_references_v36.md` | 82.2 KiB | The same, readable |
| `references/CoQ_references_v36_nt.md` | 29.1 KiB | Every cell that reads 'not tested', for review |
| `workbook/CoQ_Analysis_Master_v36.xlsx` | 773.4 KiB | The desk workbook — coverage, registers with the 10-11.09 issue dates, Reconciliation 09.09 |
| `desk/qc_quality_desk_artifact.html` | 3.1 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 21.6 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/batch_dates_2026-09-10.csv` | 5.4 KiB | Harvest and packaging windows per batch — where the internal CoA's testing dates come from |
| `sources/icoa_register_2026-09-10.csv` | 24.9 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 25.0 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 10.9 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/OPEN_ITEMS.md` | 53.2 KiB | Everything still the owner's to decide — what was found, what the desk did, what is being asked, and the evidence behind each |
| `docs/RESULT_SUPERSESSION_2026-09-16.md` | 13.3 KiB | Does any certificate print a result the record has replaced? The sweep over all seventeen determinations — READ THE COVERAGE TABLE FIRST: no lot on file carries a second heavy-metal certificate, so #11 could not be compared at all |
| `docs/HANDOVER_RESPONSE_2026-09-16.md` | 13.0 KiB | The parallel desk's audit of the 127 rendered certificates, answered finding by finding — four refuted with the comparison counted, three confirmed |
| `docs/TRUTH_CHECK_2026-09-15.md` | 7.7 KiB | Every parameter result and every cited document checked from the primary records forward, by a code path that imports none of the builders |
| `docs/VOCABULARY_2026-09-11.md` | 88.9 KiB | The 11.09 audit of parameter values and references: one spelling per assertion, and the laboratory verdict the desk could not read |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 18.8 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 31.5 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
c4dd25ee950c2af0141d40e4b0db1427c504ecff3b256bf211a97d5aa5fc3008  certificates/individual/DRAFT_CoQ_BG1024_reissue.html
04da6b93b3990d293a04680f15c3f3f6befd6dbf95244bedfa3e988d5e675780  certificates/individual/DRAFT_CoQ_BSS1024_reissue.html
9ee88e1cc4a50ffddf52af83cdad87e70700efeb593ed5fb07af33908b8f0763  certificates/individual/DRAFT_CoQ_GG1024_reissue.html
c94a2dd8e2f6eb738a2e0d679b49154fdb3871906193c6b041aa9c8464014839  certificates/individual/DRAFT_CoQ_HPA1024_reissue.html
6b95e983731ca8f79208ca2a6e0f48a833463468adae563cec81f309bb5243c7  certificates/individual/DRAFT_CoQ_OPM1024_reissue.html
78b1ab3c1d17934ed12e7ff32fa39189de4530ce4dd77b7b485694e7c37f635b  certificates/individual/DRAFT_CoQ_P050022.html
1c45ae3ada5c2d7b20ec4e9487ddfee1b8774e079c446f0d1c5082c86f6c16cd  certificates/individual/DRAFT_CoQ_P050022_reissue.html
c1ff84655d030a7c584cff67636d0fcf89e8674bae5f81dc4554503cabffc447  certificates/individual/DRAFT_CoQ_P050042_reissue.html
554d0719aa7b41f3970b805b6b8e6b07f6ad93e3aea61b6e0c842ec2627b4cb8  certificates/individual/DRAFT_CoQ_P050052.html
61ca80d0900b0c992a53b569f609bd9908e543fb6211fdff80b5e4c6b6af5675  certificates/individual/DRAFT_CoQ_P050052_reissue.html
807502681fe0dc363242424502f7d32c1e2bbce72f11d012cabb7a0f40962a88  certificates/individual/DRAFT_CoQ_P050062.html
e276b026931a77d89636b39cf1cc172e3f146dea299f751eae63a0a96ee6f6cf  certificates/individual/DRAFT_CoQ_P050062_reissue.html
482e3d744667d0e538e430379fbab582ed6b261e5dc969e27c9e9b7efecdad6b  certificates/individual/DRAFT_CoQ_P050072_reissue.html
a206d6db3d3582f2ef806e4b35ffe3f359a3b21276302fbcfa49fb4f6650c5f8  certificates/individual/DRAFT_CoQ_P050082_reissue.html
6cd34ee7372cb3ccbccf74fe11a88538a8418d6b64e31960759992c01b4ef030  certificates/individual/DRAFT_CoQ_P050092.html
94143c84519185ba412a362a64484f54ea5b7b0e955634d1c1c8c9a4632a76c8  certificates/individual/DRAFT_CoQ_P050092_reissue.html
71a2f09f3761548cd321dc47bbeef7a8a6d26562459c41748f154d6e22f500c9  certificates/individual/DRAFT_CoQ_P050112.html
22a37a19de5ef27ca9426ddb2a98c402963837b730d19b581d3b31f83e22aec2  certificates/individual/DRAFT_CoQ_P050112_reissue.html
8025971313d78333ac207ce7ff6c987709d4d39afe5dfe773fa07c3fb6de62dc  certificates/individual/DRAFT_CoQ_P050152.html
83e189f510db83f8cccc2aeba94dbfad9a3cde1c1a4496d3e17ce9afea83b487  certificates/individual/DRAFT_CoQ_P050152_reissue.html
cc0708703a0de4f1d74efcb52d0461a6d2ba0562ffa1ba1ff084157753d021bd  certificates/individual/DRAFT_CoQ_P050162.html
24f08f50e054c4041eb08a6448128077794674d5ce08d5b28efd94c9fa4e9d06  certificates/individual/DRAFT_CoQ_P050162_reissue.html
d6f973c220190deedc3460f02827739e2b7dd6c6ea225a40438e8073f7dbe95f  certificates/individual/DRAFT_CoQ_P050182.html
6c52dd9561e3c76bf0f2dbc10d97a26a8a535823c09fa716883e4a32f9f831e1  certificates/individual/DRAFT_CoQ_P050182_reissue.html
af4e245200bc7e529e8d79b4434d4a22d78b3787eb8b680701791c94f11cc56f  certificates/individual/DRAFT_CoQ_P050192_reissue.html
7252befe38aa89118937a69baa04b9387d21e3cabf8ed492dbd30f699b0c9091  certificates/individual/DRAFT_CoQ_P050212_reissue.html
5ebcbdd1f0a352e6d6ec6de424cb18ed5ccf5137dfc69a2f4061c30966277c79  certificates/individual/DRAFT_CoQ_P050222_reissue.html
753491d4f03aae9555508ba0635eb15c94244beaeb41b8a37eb441a221028a43  certificates/individual/DRAFT_CoQ_P050282.html
b9bdf50093978648431403c2e37dbe1de6bbb7ca8b1d5c6a2d3ee480441bdfd1  certificates/individual/DRAFT_CoQ_P050282_reissue.html
60635ce3a49e50b0d4714bbe0087097d73b3f288b3bd9ef90a4163db40144026  certificates/individual/DRAFT_CoQ_P050302.html
30f1dfb454cf45bc6c2ca3627db2ddc91f6b143c702b7c8bc0bea562035fe6c6  certificates/individual/DRAFT_CoQ_P050302_reissue.html
ecd130b86af6683223ea922a5efb9e01e892876f84cb7051a482b7b4d5cd7172  certificates/individual/DRAFT_CoQ_P050312_reissue.html
12421b30380ee2ce6db08db6bc314ab2625d92f4e0641a7a0b125d0501a57452  certificates/individual/DRAFT_CoQ_P050322.html
09f71e0cc1327d3d893fd08cdaa13df62ccc5e8d5047b0a00479b7e16387a9d5  certificates/individual/DRAFT_CoQ_P050322_reissue.html
70e0b1caa3e6a1212e24b0c1ac6564bf0d7b35e685e0162d2701110fc0dfdc44  certificates/individual/DRAFT_CoQ_P060012.html
a7d550359cba1718b4d4618556bb52cf36211e18745d39b6edc32ff6d465c309  certificates/individual/DRAFT_CoQ_P060012_reissue.html
430cc1f81beba9314126b020b6ed283f83ec6e73c0c75daedf998ea044567ea4  certificates/individual/DRAFT_CoQ_P060022_reissue.html
52cd04f820783b2ff768ecc1f6215b6725f1fc70e609f88f4c1329d245c7adc7  certificates/individual/DRAFT_CoQ_P060032.html
8128db10d2663a1f46625961f777bc7c0866a323dc47603e36a70a36dadeea1d  certificates/individual/DRAFT_CoQ_P060032_reissue.html
5d9dfd26dda349a122103912a5d29b888672f258b89cf26e061ab3cddc0bf172  certificates/individual/DRAFT_CoQ_P060042.html
bfa3e4ff1516c66080bd12623b61af7f065811e6dbf039003c7ece6fd17959ad  certificates/individual/DRAFT_CoQ_P060042_reissue.html
efc4e87de003675d2f0a4bcda49450f7d07c561d689b9e436603036c872adabb  certificates/individual/DRAFT_CoQ_P060062.html
5937d13ccff054931d01b3258ab22013830b8e3efa1213db5f6ef55324a4e9ac  certificates/individual/DRAFT_CoQ_P060062_reissue.html
937d80340c164197118332f6fa271a57d0bba2e4613ce012a6810b2335020ecf  certificates/individual/DRAFT_CoQ_P060072_reissue.html
c27bc4af4a7d3c198a931b2212ba1a86f944f8e9a3a60a90fcf2e4d09ed8e458  certificates/individual/DRAFT_CoQ_P060082.html
3adcf0c8a58a597c9ad6ed553173ee8dc4f4cd0ed1acb7726c675cdc98c9aea9  certificates/individual/DRAFT_CoQ_P060082_reissue.html
e890d444c0a904e356e5fd972ae9982b3636a01f2dbb350f4df5d3fab8f005ce  certificates/individual/DRAFT_CoQ_P060092.html
f488e6cebd3d97ea60844d144ef7a65a03dbf212ee315a5d5fe7d1bb5c1001cd  certificates/individual/DRAFT_CoQ_P060092_reissue.html
e2a89d1b39ac14bab0a85d34736507fa1664d2ad267180ca3eaffe9b495312d5  certificates/individual/DRAFT_CoQ_P060112_reissue.html
61224dadc1bbae294e8e79a22e7f653881cf9f7261728670e9a430ce0abee099  certificates/individual/DRAFT_CoQ_P060122_reissue.html
e633656eeb8781f80a19b45575fc19ed3767f77a39fbef0a56dd52faab6c681f  certificates/individual/DRAFT_CoQ_P060132_reissue.html
bfd2f672fea569f478bc225653e25d301848c3f02d441571fc0279ad5034c9a3  certificates/individual/DRAFT_CoQ_P060152.html
231ea5a1554c8f28f35b9578fba673be41fb7f2f64d7d6aeb18b30b80eed4d9b  certificates/individual/DRAFT_CoQ_P060152_reissue.html
93f9fe2d0d28d97109da8d937e0d032c817e44d2821e4870f76b17b9b5021b3c  certificates/individual/DRAFT_CoQ_P060172.html
677638c3424757f4ad345aa4e4e5e2b6d112aa83cc1a23e9be01c3387b2f01aa  certificates/individual/DRAFT_CoQ_P060172_reissue.html
b38da37bb3b3b5a71aea1570885208a8dbf953e1ca7f0c4b6bd8c9d4e37f8634  certificates/individual/DRAFT_CoQ_P060182_reissue.html
359b62e96469a7f609f05cb1db3fe78f453c3a07f8a21a6b32d076a34edbee26  certificates/individual/DRAFT_CoQ_P060212.html
f8dbf8496aeb506c40b3e208a7ebf341965360dd0853a54352609720174d9a68  certificates/individual/DRAFT_CoQ_P060212_reissue.html
c899f822a2d526cf2f12adc28338320ee7aacabe6d7317793d9fccca92524495  certificates/individual/DRAFT_CoQ_P060232_reissue.html
a1e0bba3762d3275ef58df1efe292b5741985bc477f50495b433a92b194851ae  certificates/individual/DRAFT_CoQ_P060242.html
25014d143da2db78ccb4f4bce005f3cffa1f942ffa4f8e07cebec0ce98a1259d  certificates/individual/DRAFT_CoQ_P060242_reissue.html
8e39fc1d61cd7a4cbfd4b9d528141de85d189b6f6d9cb22ed576960912442363  certificates/individual/DRAFT_CoQ_P060282_reissue.html
a5dff9cd6e20cec8b49297fbb6bb8c3f4a6181b4198976b72b63bb95577e02f6  certificates/individual/DRAFT_CoQ_P060322_reissue.html
c5366800536a703472f034230acb61904921f490f52d21433c3e77c7404115f0  certificates/individual/DRAFT_CoQ_P060332_reissue.html
68c136ede60eef27ae0f7033ac6309f4c9f51b9c8ffe766d169a6843f631fd66  certificates/individual/DRAFT_CoQ_P060352_reissue.html
d506d218c1cd314f744c56db31fbb8afff8fd7c452efd33a2abee29a2c0918f1  certificates/individual/DRAFT_CoQ_P060362_reissue.html
3713486c76a3aa5870b7ad7acf3d87cef710530307908e781b1464f61dc91417  certificates/individual/DRAFT_CoQ_P060372_reissue.html
46b93602b109a12d7178abba92e0bc96d378042bad35b49ae49e0208c31baed8  certificates/individual/DRAFT_CoQ_P060382_reissue.html
e17455f85865b09e037288fff412ea44d0d6124dfbfd5307740e92ae94cedc60  certificates/individual/DRAFT_CoQ_P060402.html
bcf2e9857767176ecd6dafc46d79a02f94f46b6ccced154167ae0a465ddee561  certificates/individual/DRAFT_CoQ_P060402_reissue.html
c0c65c6c89587adec08e315da07540871c6beae6d0d26221a4291c1493ea5282  certificates/individual/DRAFT_CoQ_P060412_reissue.html
9995b8ae37bde9e5d873b48c81cf3448162c40f4e87e4b4d17908ac1c5fe91d0  certificates/individual/DRAFT_CoQ_P060422_reissue.html
3e32d1c1d5c23ba91341eb9caed3366b7ba6b3e46f42c025222b8b48d1aa7c7a  certificates/individual/DRAFT_CoQ_P060492_reissue.html
e396d0e21fe89a186e879f11a0d8267940a6316b3a855903114856b3c47b002a  INDEX.html
89a0f345bbc0273102b72564f101e9cceeb54d25c8b0caff2cd9b54f2825c3f3  certificates/Tranche_1_2_CoQ_Draft_Set.html
97a07053d039ce7aeb04808259048b898842ee4e2d1e3ad45758205ab38b7057  certificates/Tranche_1_2_CoQ_Reissue_Draft_Set.html
f80bd16d5e9186c89a62cd67ae1cccd4577e91db015d244becab8447837fb937  compilation/CoQ_compilation_v36.xlsx
86f318d830c5ea9384ecc7514a5256385c0be951b2155c3e7b15d1f18ae6abf1  compilation/CoQ_compilation_v36_wide.csv
35c951b9c8e287cca6185adc97103ce52fee37abaf2a4edf9736a904783c2a10  compilation/CoQ_compilation_v36_long.csv
a1ac1b695fa8fbc2a69b4bd37b7712abaf7a89339cd09eb130fe508be29236b4  references/CoQ_references_v36.xlsx
684f769cc98ebb389ba016cd0083f2a336220aa39cb16460eab8934da5515261  references/CoQ_references_v36.csv
14b364fb3dc6eeb3cd233fe84f8a101a80901507faf6a9d6567bd245ab742b4e  references/CoQ_references_v36.md
53f038eb89185c23b6048beaa1a76d43af228d6032a13144c02918458d831afa  references/CoQ_references_v36_nt.md
42681d22267a79461ec4469280a434469faffa27eb928b49653bde5b166f8247  workbook/CoQ_Analysis_Master_v36.xlsx
8b7b8a8ba97ef87b49e198f549b42a5db65929b5d7c6d6cc99dea1100a2fee93  desk/qc_quality_desk_artifact.html
72d1dc298f882dab8dae4114e217e73241a524cef346b927b41ea2c4e74e04a1  sources/issuance_schedule_2026-09-10.csv
22f2e9cc57bdbc1fab4a8ee8cc3146d34ee647515a5e294a9781526f79f047f9  sources/batch_dates_2026-09-10.csv
b80017375e13c7a11e543fc11a3b7cacacb50894e0e62038b1b0f047977c4ba7  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
604db64c1e818b8634205cea00f961f79e86487eaed057f301235192a39a8785  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
20f81e9311281b0682f9670c5ba8f2b2f5cc6d88de4682f77dd1855b5f346a26  sources/coq_draft_gaps.csv
40ecec761daf3207d03009290b886bbf3492aa1a4a36001a53df535d67ead1ca  docs/OPEN_ITEMS.md
88c8f09fcc3b16ab08e2a3bdb6a15ccca9a6ef3a3f9b013fb7ecf836ee76273b  docs/RESULT_SUPERSESSION_2026-09-16.md
f7315cbf159508aaf14c125324313e970fb7d7308364630e0ce9df67a59c3498  docs/HANDOVER_RESPONSE_2026-09-16.md
87c737d23bd53fc715e35f87c069892bc6b390bcdfc2c65d791a28f5df7e2bf7  docs/TRUTH_CHECK_2026-09-15.md
d58d0652653cbcf52a434465335c1867d2f401359c4105fe016815e64d5e0c30  docs/VOCABULARY_2026-09-11.md
2f86d9e6ae5800af08077c3a90d659b71e9758cfdd75a59f0511669a2ce2b7e8  docs/ISSUANCE_RULES_2026-09-10.md
101232cbe02dabe959f4ac14e3f9bdd773bfa6ff42bf2172d41b88389a7f157f  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
