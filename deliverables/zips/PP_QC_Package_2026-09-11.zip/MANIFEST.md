# Purely Plant — QC package, 2026-09-11

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 77.9 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 77.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 18.1 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_CoQ_Drafts.pdf` | 18.4 MiB | Tranche 1 — 13 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_2_CoQ_Drafts.pdf` | 12.8 MiB | Tranche 2 — 9 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 863.5 KiB | All 22 certificates as one scrollable page |
| `workbook/CoQ_Analysis_Master_v23.xlsx` | 248.0 KiB | The desk workbook — coverage, registers with the 10-11.09 issue dates, Reconciliation 09.09 |
| `workbook/coq_master_v23.html` | 690.3 KiB | The same workbook as a page, nine views |
| `desk/qc_quality_desk_artifact.html` | 3.0 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 12.1 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/batch_dates_2026-09-10.csv` | 5.4 KiB | Harvest and packaging windows per batch — where the internal CoA's testing dates come from |
| `sources/icoa_register_2026-09-10.csv` | 10.6 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 18.2 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 18.3 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/OPEN_ITEMS.md` | 14.1 KiB | Everything still the owner's to decide — what was found, what the desk did, what is being asked, and the evidence behind each |
| `docs/VOCABULARY_2026-09-11.md` | 9.9 KiB | The 11.09 audit of parameter values and references: one spelling per assertion, and the laboratory verdict the desk could not read |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 15.1 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 31.5 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
8996643c0adb74248b255c5d7c4d994a0d255565c438b99e9f0659966d045df1  certificates/individual/DRAFT_CoQ_P050022.html
fcf1fdcec0c7aa16e9b50a8f429dd151e2d07b6523f99cd99676121f0c2e57e1  certificates/individual/DRAFT_CoQ_P050052.html
33901393bff2d4f5f55e431f3e79655b911aa7caeaa8f78a5d457f8c698d0a82  certificates/individual/DRAFT_CoQ_P050062.html
165b247307c6fcc7090cacbf9025bc001c3ff59677d109a0653a45190c1c045d  certificates/individual/DRAFT_CoQ_P050092.html
a686995a971a42c24e701eda673797e28e88283d61f1161ceae85f71e3072b13  certificates/individual/DRAFT_CoQ_P050112.html
bc6bf5ce07ba71e0465688520be9b87a0b15d8a19b463295d193f452a69e14db  certificates/individual/DRAFT_CoQ_P050152.html
cde34e8114a786c828f2091480ffcbec5339be081b014b2ec055da558d81162b  certificates/individual/DRAFT_CoQ_P050162.html
9bd6fea39182d3eddb577bf682aa33f2146889405cbadb4d06a572012170507c  certificates/individual/DRAFT_CoQ_P050182.html
ac82f3c5073109f0b137680f35e19a36f0142508e6f30b7dc9724e467105ffee  certificates/individual/DRAFT_CoQ_P050282.html
d98b82a41a58924db993060f262775e02e46d28fe1aeb7c7bd9591dc0e0bac59  certificates/individual/DRAFT_CoQ_P050302.html
9908710d94177d6fca0b79d5b0be9de542271459e4083d062fd02fb7abbf6dc9  certificates/individual/DRAFT_CoQ_P050322.html
066836e04db1d6a7faa8e9735342c722d9f261312ffa837f9ff6715fd5025541  certificates/individual/DRAFT_CoQ_P060012.html
469891aa03b5d468a3985652446256baded907be2844a5af92d82c597c398e3f  certificates/individual/DRAFT_CoQ_P060032.html
151822900f17d7c3c50e1178558f4043a36753750882c3f82c6230733797fd93  certificates/individual/DRAFT_CoQ_P060042.html
a258cd16a134e77237330dd3bf03dd07b9324985ff6945a5dd7f2e5dfe070cd2  certificates/individual/DRAFT_CoQ_P060062.html
6701a6662dab20bedad9d4f4cf93d2590a39e206d41ac718e786c1508591fb02  certificates/individual/DRAFT_CoQ_P060082.html
e3769e6ca62912414ad6ca043592c399874bcc5182d31921b78e3ac2ce3af017  certificates/individual/DRAFT_CoQ_P060092.html
5a54952cb2bdf23ccefb7b4700d0b97d7179e8da0671af52ea9733d9416a0539  certificates/individual/DRAFT_CoQ_P060152.html
ab7b5edcc3de75b9219ed5a259ddc3db0b3d59a999443aa4aa9bdead0a7c01c7  certificates/individual/DRAFT_CoQ_P060172.html
5a74e74305578889992a4f58b5f6cea1457b8d2622facb213afc6d98e66d0aa7  certificates/individual/DRAFT_CoQ_P060212.html
ef6ad1104d6a09f976980e4f3e5ebd97a9f8e7f9973c432be2c9be9f2d46fcd7  certificates/individual/DRAFT_CoQ_P060242.html
6dd2afc235e8ac26cf46fa6027f794fae702e40856af539ef152ad471aac4304  certificates/individual/DRAFT_CoQ_P060402.html
e396d0e21fe89a186e879f11a0d8267940a6316b3a855903114856b3c47b002a  INDEX.html
aab935a1dc76800a756e70735b826fbe9ba0116f8ca91bf08085724b046e11d3  certificates/Tranche_1_CoQ_Drafts.pdf
f9908ebdd07665de6b55e66c3d7baf1a8e17c20ab1e867de524993424e35f02a  certificates/Tranche_2_CoQ_Drafts.pdf
91854e14eb3ce4bae11e447566e6483e028ad2fc326b5ba60ec74dd3b20de667  certificates/Tranche_1_2_CoQ_Draft_Set.html
2391ad273a0b6fb372e68e8b8af5fb30ba0ede17a3cbbb59fb800d3793d7d4cc  workbook/CoQ_Analysis_Master_v23.xlsx
a21c9f94d1b3c191ee010b5d33c369a3351a6649db32d3bceae6bf1fb9f91261  workbook/coq_master_v23.html
1ad505ecce30e0b2c0306990f57ae2475d5929cfb61406f4e1df628d94daad30  desk/qc_quality_desk_artifact.html
a32098699991e814661aed6a9ab51182b242baecf86d258344955507c9b4eedc  sources/issuance_schedule_2026-09-10.csv
22f2e9cc57bdbc1fab4a8ee8cc3146d34ee647515a5e294a9781526f79f047f9  sources/batch_dates_2026-09-10.csv
55a883482b08c5a4cf7f7ebd5ce16f5a002ba54854c0dc483f2052a83950c4fe  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
4a0b505e56165d717f90e459838a8c4743ec06a6fb09e512477fda98f4ff863e  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
ef5ebe8c29d0d636399383fe14da22a0314769dcc6d4dfb2f6206e5beb07ba2b  sources/coq_draft_gaps.csv
801c6576e0277768a6311f9c74cef5fee6a6d9e52b1e57f65cc7fedf62fee94b  docs/OPEN_ITEMS.md
1732bc702c4d6f2dec20b2cc2c832d8b8b7a46d1f77fd88a916f3cad2aa365dc  docs/VOCABULARY_2026-09-11.md
4860e03897b8cbb35c9ee4ff1add11a928191be43ed86137baf35f51136b34bc  docs/ISSUANCE_RULES_2026-09-10.md
101232cbe02dabe959f4ac14e3f9bdd773bfa6ff42bf2172d41b88389a7f157f  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
