# Purely Plant — QC package, 2026-09-11

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 18.1 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_CoQ_Drafts.pdf` | 16.8 MiB | Tranche 1 — 13 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_2_CoQ_Drafts.pdf` | 11.5 MiB | Tranche 2 — 9 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 861.0 KiB | All 22 certificates as one scrollable page |
| `workbook/CoQ_Analysis_Master_v23.xlsx` | 248.0 KiB | The desk workbook — coverage, registers with the 10-11.09 issue dates, Reconciliation 09.09 |
| `workbook/coq_master_v23.html` | 690.3 KiB | The same workbook as a page, nine views |
| `desk/qc_quality_desk_artifact.html` | 3.0 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 12.1 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/batch_dates_2026-09-10.csv` | 5.4 KiB | Harvest and packaging windows per batch — where the internal CoA's testing dates come from |
| `sources/icoa_register_2026-09-10.csv` | 10.6 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 18.2 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 10.9 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/OPEN_ITEMS.md` | 18.6 KiB | Everything still the owner's to decide — what was found, what the desk did, what is being asked, and the evidence behind each |
| `docs/VOCABULARY_2026-09-11.md` | 16.3 KiB | The 11.09 audit of parameter values and references: one spelling per assertion, and the laboratory verdict the desk could not read |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 15.1 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 31.5 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
868b848416655bb64d0bb12089683f8b9a622f70d4b41923d85b767fae392d6c  certificates/individual/DRAFT_CoQ_P050022.html
1d2c7c65504e8ff16ab7fc977c5a32294afe7c2050940e2fdc7af82c3df54bbf  certificates/individual/DRAFT_CoQ_P050052.html
2e4e7e9191d6169674b76a510ad5a1cf8d9d8de9bf41c8e61cf7c23dd36476aa  certificates/individual/DRAFT_CoQ_P050062.html
5a5d826e0371e07325a51436fc4990deea5ab4a6722384c83bf44e568f499772  certificates/individual/DRAFT_CoQ_P050092.html
146dba5274ba34a415d83912a24590716573c9d981db8a46999f375c7b20c43e  certificates/individual/DRAFT_CoQ_P050112.html
dc10573345aa3f85cf7168e84fcba75cbfff9f7893b27b10e51617151f35c220  certificates/individual/DRAFT_CoQ_P050152.html
0b9f3c014f0b9b4f06294f14ffc916b86b9c2ad10855bb339efaacb14a57115e  certificates/individual/DRAFT_CoQ_P050162.html
4bd2300252842e9421e5ab4685fe463947d27977e4c73b452d1d76c381f3451b  certificates/individual/DRAFT_CoQ_P050182.html
299eb57fd9795012812c210a05c3e15f0a3caca2a724a644654252176048bc52  certificates/individual/DRAFT_CoQ_P050282.html
30857ca12a0f21fcc5aeade4daccec9854952853629d8b662f43876b70cab361  certificates/individual/DRAFT_CoQ_P050302.html
2a687f16847428379e308e22a8dcf2ab5872c7487ef4b46b8add79391e8740af  certificates/individual/DRAFT_CoQ_P050322.html
f155413d661e07e222b640e3af709177c843a9107b0c7fba9d7489f2a063e939  certificates/individual/DRAFT_CoQ_P060012.html
ac49d49f06c120bbd7fc9266885165c8d87b0e766c13b0422f39204f90a0a129  certificates/individual/DRAFT_CoQ_P060032.html
54eebb9142363a904d08f8c47775e5e54d5897bfce391b94ab396880e21baa3d  certificates/individual/DRAFT_CoQ_P060042.html
fcf0f791c49c64e4e0f5d424fccfc910416b9c29bd33f7eb53f5df582ebba961  certificates/individual/DRAFT_CoQ_P060062.html
5a90a889eab457becf31c75e76a6aeb9cdd2cb0116a784de5f8f53ddc7089807  certificates/individual/DRAFT_CoQ_P060082.html
b92baaa03a51aaa741e6bed5958bf06e9948fe45cebdc60044c7c8fad71905d3  certificates/individual/DRAFT_CoQ_P060092.html
b7613f3e6447a05a41c72b70073eacb6cf4ec7bde88106a2da9acd8786fb5724  certificates/individual/DRAFT_CoQ_P060152.html
131d479eeb72162c7be3daf61856cf2b346a062d2cd1f9abae66f9753904d429  certificates/individual/DRAFT_CoQ_P060172.html
483734c322faa6686df747f6ac10e39aada8a97a6123c43bb782e3cd773059d5  certificates/individual/DRAFT_CoQ_P060212.html
4d9f3cd92162353365ae1e019586eab81a220dba8047c6f51c43929030e9e585  certificates/individual/DRAFT_CoQ_P060242.html
b02e3cdd75609514a9eff157bf014ae529316196ae043cc55f96ab658575e54f  certificates/individual/DRAFT_CoQ_P060402.html
e396d0e21fe89a186e879f11a0d8267940a6316b3a855903114856b3c47b002a  INDEX.html
1065711691d7346722d587ff74e452b6703dc0b8f4ef8ae00ca61892f198659d  certificates/Tranche_1_CoQ_Drafts.pdf
6d911b12facb4dfa6d23b347a1294c2338c572fa562605094053f2e3bc4709be  certificates/Tranche_2_CoQ_Drafts.pdf
fd8d342d0a9add44a23c2bfc6053344eb5c74d9e77a6cffbf79c6c4191e1a664  certificates/Tranche_1_2_CoQ_Draft_Set.html
2391ad273a0b6fb372e68e8b8af5fb30ba0ede17a3cbbb59fb800d3793d7d4cc  workbook/CoQ_Analysis_Master_v23.xlsx
a21c9f94d1b3c191ee010b5d33c369a3351a6649db32d3bceae6bf1fb9f91261  workbook/coq_master_v23.html
a98573cd9666b60c15bb2587cd5b4716f6af2242ad64ad0b6e4a486adb2245fa  desk/qc_quality_desk_artifact.html
a32098699991e814661aed6a9ab51182b242baecf86d258344955507c9b4eedc  sources/issuance_schedule_2026-09-10.csv
22f2e9cc57bdbc1fab4a8ee8cc3146d34ee647515a5e294a9781526f79f047f9  sources/batch_dates_2026-09-10.csv
55a883482b08c5a4cf7f7ebd5ce16f5a002ba54854c0dc483f2052a83950c4fe  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
4a0b505e56165d717f90e459838a8c4743ec06a6fb09e512477fda98f4ff863e  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
20f81e9311281b0682f9670c5ba8f2b2f5cc6d88de4682f77dd1855b5f346a26  sources/coq_draft_gaps.csv
986a15ed6d37112983a07ae0e128c54593b8bd331abf5e9b78559fe6e81e7204  docs/OPEN_ITEMS.md
90281df1ff2bb0fd824087ac532053ef6ed80d6a8926626994042d19e757b4de  docs/VOCABULARY_2026-09-11.md
4860e03897b8cbb35c9ee4ff1add11a928191be43ed86137baf35f51136b34bc  docs/ISSUANCE_RULES_2026-09-10.md
101232cbe02dabe959f4ac14e3f9bdd773bfa6ff42bf2172d41b88389a7f157f  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
