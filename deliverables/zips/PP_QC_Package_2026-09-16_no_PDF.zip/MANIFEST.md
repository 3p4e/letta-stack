# Purely Plant — QC package, 2026-09-16 (no PDFs)

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

The four compiled tranche PDFs are **not** in this archive — they come to
104 MiB together. Every certificate is still here as HTML, individually
under `certificates/individual/` and as two scrollable sets. The PDFs
download on their own from `deliverables/qc_gap_analysis/drafts/` in the
repository.

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_BG1024_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_BSS1024_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_GG1024_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_HPA1024_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_OPM1024_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050022_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050042_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050072_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050082_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.7 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050192_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050212_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050222_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050312_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060022_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060072_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060112_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060122_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060132_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060182_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060232_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060282_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060322_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060332_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060352_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060362_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060372_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060382_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060412_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060422_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060492_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 18.1 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 860.7 KiB | All 22 release certificates as one scrollable page |
| `certificates/Tranche_1_2_CoQ_Reissue_Draft_Set.html` | 1.9 MiB | Every reissue as one scrollable page |
| `compilation/CoQ_compilation_v35.xlsx` | 418.8 KiB | The owner's first request: one row per certificate of quality, and for every determination #1 to #12 the result, the document, its date of issue and its laboratory |
| `compilation/CoQ_compilation_v35_wide.csv` | 321.4 KiB | The same table, one row per certificate |
| `compilation/CoQ_compilation_v35_long.csv` | 1.1 MiB | The same table, one row per certificate AND determination, with the method, the acceptance criterion, the sample receipt date, the status and the route |
| `references/CoQ_references_v35.xlsx` | 35.4 KiB | One row per certificate, one column per determination — the document each rests on |
| `references/CoQ_references_v35.csv` | 76.0 KiB | The same, flat |
| `references/CoQ_references_v35.md` | 82.2 KiB | The same, readable |
| `references/CoQ_references_v35_nt.md` | 29.1 KiB | Every cell that reads 'not tested', for review |
| `workbook/CoQ_Analysis_Master_v35.xlsx` | 772.1 KiB | The desk workbook — coverage, registers with the 10-11.09 issue dates, Reconciliation 09.09 |
| `desk/qc_quality_desk_artifact.html` | 3.1 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 21.6 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/batch_dates_2026-09-10.csv` | 5.4 KiB | Harvest and packaging windows per batch — where the internal CoA's testing dates come from |
| `sources/icoa_register_2026-09-10.csv` | 24.9 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 25.0 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 10.9 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/OPEN_ITEMS.md` | 51.6 KiB | Everything still the owner's to decide — what was found, what the desk did, what is being asked, and the evidence behind each |
| `docs/RESULT_SUPERSESSION_2026-09-16.md` | 13.4 KiB | Does any certificate print a result the record has replaced? The sweep over all seventeen determinations — READ THE COVERAGE TABLE FIRST: no lot on file carries a second heavy-metal certificate, so #11 could not be compared at all |
| `docs/HANDOVER_RESPONSE_2026-09-16.md` | 13.0 KiB | The parallel desk's audit of the 127 rendered certificates, answered finding by finding — four refuted with the comparison counted, three confirmed |
| `docs/TRUTH_CHECK_2026-09-15.md` | 7.7 KiB | Every parameter result and every cited document checked from the primary records forward, by a code path that imports none of the builders |
| `docs/VOCABULARY_2026-09-11.md` | 84.1 KiB | The 11.09 audit of parameter values and references: one spelling per assertion, and the laboratory verdict the desk could not read |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 18.8 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 31.5 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
c08d351298f14108d29c11810df64b7d1d5804d072b58007c0434a0d2e9c15c2  certificates/individual/DRAFT_CoQ_BG1024_reissue.html
51efe8a899860134bb1a4f6fe3b3361521afed5db3eff34ef584cc93c6e8220a  certificates/individual/DRAFT_CoQ_BSS1024_reissue.html
1f9d13503d3da5625cb968c1b9f9cae2f1cb1685eb12e09d65cc0d5170ae2253  certificates/individual/DRAFT_CoQ_GG1024_reissue.html
37fd095334e0842c19d10d871b0847e788e60ce2dd9cb2ac34fea69a03543d74  certificates/individual/DRAFT_CoQ_HPA1024_reissue.html
ef0568b87c9b80c1d3cb5d1eda5076f038775162d5a63b0f2e1446b4b973766e  certificates/individual/DRAFT_CoQ_OPM1024_reissue.html
1b2527ba87b5dca2c1196657514f8f8fc3174bcc3b75ccc717110a5d19b1eb30  certificates/individual/DRAFT_CoQ_P050022.html
389335e41dc6cce818cad9a98b5435989aeb570071bbcf25527882726fdf772b  certificates/individual/DRAFT_CoQ_P050022_reissue.html
2ac4d677bace538993b91f024406f0d1488e4c92f7bfe5723e7c803e881f1db6  certificates/individual/DRAFT_CoQ_P050042_reissue.html
da6f436c58bb3742eb3ecb9c9d533b2c0df227babe1ad778a11ee718d3eb26dc  certificates/individual/DRAFT_CoQ_P050052.html
82a16faf79cb3389066b445959b6edb5795f25e4c2217fed522f0301a9456c52  certificates/individual/DRAFT_CoQ_P050052_reissue.html
e9d9533f7ad9acb8e68fe39d209871872bc56ef803ae8e240263c1095652e26a  certificates/individual/DRAFT_CoQ_P050062.html
3803f6a20d7964675c2cfd9d7e7cc0ab366cf263521cd08b56e5fb5ca15d0b6a  certificates/individual/DRAFT_CoQ_P050062_reissue.html
dd185662041ca35c6449a2ccad21f32dae0e9267a2ceba88f1a8a533fc79f4d4  certificates/individual/DRAFT_CoQ_P050072_reissue.html
dd101b930d5d2e324e70d05c37e1f330627df7573c08ce262985e6ecdbe69a19  certificates/individual/DRAFT_CoQ_P050082_reissue.html
d536e6102db34edd2cbb3844edf830226938bc37348eafdd796f55aa2bca43f2  certificates/individual/DRAFT_CoQ_P050092.html
d1ebf276de3e7067c80421eef20079354e8283727a9ba87249d29bce869e80f3  certificates/individual/DRAFT_CoQ_P050092_reissue.html
9e8489b171b1d95465140deee95343f659c5574426009a926f1b21302d529b91  certificates/individual/DRAFT_CoQ_P050112.html
621d79f7364d90b4a19fb3ec03954816d88c2359f2def717fb884d3d94161725  certificates/individual/DRAFT_CoQ_P050112_reissue.html
5899448dc734b765e16dc4e35d6a5884d27cfd6b6b8da38fa3952817a1cc9c25  certificates/individual/DRAFT_CoQ_P050152.html
1f43b067e836cfea4afb66ed3926da198f5042d45d6f9676a8c50f931df8c0bd  certificates/individual/DRAFT_CoQ_P050152_reissue.html
f576469e51c8514b0dccc37ee5f43cfa5c907c9f079b1a8f3ebb4a2fd3248bb8  certificates/individual/DRAFT_CoQ_P050162.html
3193683820e4366368d0657cf14e83c05d3f1567df18d5638debbfe7c7af2acd  certificates/individual/DRAFT_CoQ_P050162_reissue.html
c9d2e998cfb4af9fcf5bc84b9d5b69b912bcfc4a2b3fe81f2ee070106412b506  certificates/individual/DRAFT_CoQ_P050182.html
e5221e197ac83c0c0a1a1efe359b33d71affea41b22114196530b986464c6e96  certificates/individual/DRAFT_CoQ_P050182_reissue.html
a8f1555d3a03e0cf081d21939e81b1ee31d24c98d5ddedc29529a8059aaffaeb  certificates/individual/DRAFT_CoQ_P050192_reissue.html
6d004db1179a4979552820318f5d7656c2c37794ddd1523b0e6e6ebbe21629e4  certificates/individual/DRAFT_CoQ_P050212_reissue.html
41403d0fd96ffb82e3b873c609f7f3c9e2a33f416ae1ef0e96142cbe8610f3db  certificates/individual/DRAFT_CoQ_P050222_reissue.html
bc5485475d9e27f019d64de714a0cc7bf4d504fc2e468278ec0e0f5339cec486  certificates/individual/DRAFT_CoQ_P050282.html
a50a763462b51ac3ee0c309b37858764ee816828d0c880c9e04435e3f91d12b8  certificates/individual/DRAFT_CoQ_P050282_reissue.html
5ea8a0ab57879230244b5ffeefd460c26ae6f7df614c56ca335fed9c70f508b0  certificates/individual/DRAFT_CoQ_P050302.html
ee2d9f555ea18d9e610aa72982c6c7e67d6d18ba83167eb9653429bc38812f0c  certificates/individual/DRAFT_CoQ_P050302_reissue.html
0cdeccd9f019c70d06480713392ebe033a426f63c0aca843930c614b59e59a9e  certificates/individual/DRAFT_CoQ_P050312_reissue.html
31aa9131c0ea6da1d02d42edc95977eede631dea30c05082c3779998bb342418  certificates/individual/DRAFT_CoQ_P050322.html
b455a2e0e071de71e71b2333fd3fc6525bf94fced4209dcbe3f1f4cd82806021  certificates/individual/DRAFT_CoQ_P050322_reissue.html
b16aec5b31359af5584c5820a88f0d799ab732d286e461919d8a394e75680c21  certificates/individual/DRAFT_CoQ_P060012.html
8b916f60fb54d06db6c26d2a4975e401ce17ce63e70a54b6fa5a78624412eea9  certificates/individual/DRAFT_CoQ_P060012_reissue.html
ebdc4834f8cf557f3e2f2858cbc8459c169b1070dda7b760ea8881c1c42b60e3  certificates/individual/DRAFT_CoQ_P060022_reissue.html
cb750712a978fa31a64bf312ce95ef1d2f0814c124532c45e7be9c7f88c6ccbe  certificates/individual/DRAFT_CoQ_P060032.html
6c37e6f7a51eee5a9025e7fa1186f7f007b75f53be4de73af8b94d982a732414  certificates/individual/DRAFT_CoQ_P060032_reissue.html
256696128f3a0d096139406840ad94fc307f633132918085ef1ee941d58e628f  certificates/individual/DRAFT_CoQ_P060042.html
bac96bb2bd2268c628a4fce780bacf4041f427af11bdbabe4676a0b198e5024a  certificates/individual/DRAFT_CoQ_P060042_reissue.html
efc3043573d47edcae06e3b44de9de4ceb0bbdf6d4efd52d0432dbb7c686f94e  certificates/individual/DRAFT_CoQ_P060062.html
4b4ec4369de84b78818884c18cde76afa9e1736ca7e33921cf93b2148acca0e8  certificates/individual/DRAFT_CoQ_P060062_reissue.html
fdd05bff2001e0ab510f4ac47ea00994fa3c227985a2a9c126fde5898fb09599  certificates/individual/DRAFT_CoQ_P060072_reissue.html
12f23a88c360756e4a107872c144efdd969ba38b7d6421b4c4120c557d76b01b  certificates/individual/DRAFT_CoQ_P060082.html
4c2885077524e7e42bc5c7afe499a86cda33b7cb658970968f2ac589779ae7d4  certificates/individual/DRAFT_CoQ_P060082_reissue.html
8ee69abdfe002c6d6cb68540fefcf2d59a2273b1a0124fe58b1d834311e972c6  certificates/individual/DRAFT_CoQ_P060092.html
d2595524cbacd7681ba0844b978402dd9dd4c359b969a8b5a9767f1eaf4f2e3a  certificates/individual/DRAFT_CoQ_P060092_reissue.html
add5f5fd880fcba7e6644ecc948c8a078f3844a45499a61c558cb913d2ab7da2  certificates/individual/DRAFT_CoQ_P060112_reissue.html
5c0515ef064e0be30f0fba13ef8f0e48e588abb62bc4f3d8f013321c6015cc86  certificates/individual/DRAFT_CoQ_P060122_reissue.html
ae304158caddfa61e967b661d75b81ecd742674ea24a130b376319a48697ae48  certificates/individual/DRAFT_CoQ_P060132_reissue.html
29e3259cb509f6bf9efd2d28ab4b78b869011e8d2a2368917f5b205295666510  certificates/individual/DRAFT_CoQ_P060152.html
5942d3036823a5aee2c66bc46fdbe46c32cb5d811462aedb7f5d6cb9fabf945b  certificates/individual/DRAFT_CoQ_P060152_reissue.html
3da36549013d8f6645b55f6b0c6a192225c3454ae5415260e47d7ef96f103c25  certificates/individual/DRAFT_CoQ_P060172.html
cf9d67dd779796783b60739f7e4decc83ff9d62ae8fdd34a47edef48badea25c  certificates/individual/DRAFT_CoQ_P060172_reissue.html
564276807662694a415e217bc5168dbe79eb1e1ae57bfe0003c14b7003d455b3  certificates/individual/DRAFT_CoQ_P060182_reissue.html
28bdaad08ec5a291a2a13f6a7bf65ffff21767b12504332b572c4524bc20ea91  certificates/individual/DRAFT_CoQ_P060212.html
a5978a4b9866b282feec1f52355111259ba1fd261b8482f552ee6ff44a1e50f2  certificates/individual/DRAFT_CoQ_P060212_reissue.html
e00ec25e949f92c747c1faddf4f47bbdddac55f0e9d8c55596bf24a8b5eaf625  certificates/individual/DRAFT_CoQ_P060232_reissue.html
abd6505e1616b12693176c314c12b0edcdcc42745a5b7a83e8d90e3f5b816dcd  certificates/individual/DRAFT_CoQ_P060242.html
6f647a7b1bd3b446eadee46acfd2724a01cf0c7063e7891a032830952eb2c3e5  certificates/individual/DRAFT_CoQ_P060242_reissue.html
5224aae7d9a3130f0bfa0206c2250810d9b02b70414e217e2a35ed514131aca3  certificates/individual/DRAFT_CoQ_P060282_reissue.html
907559ee76ff7ebca3a4d486768470a65f6236c3de75be451ae357c72182e211  certificates/individual/DRAFT_CoQ_P060322_reissue.html
bd3b5e5948ba6289b1c8d468739cd0cab52294a742986623652b834a2c28c1f2  certificates/individual/DRAFT_CoQ_P060332_reissue.html
36db41c32bfb1caca170320b07f0f7121b0e61379460a0cb506da5fae9174adf  certificates/individual/DRAFT_CoQ_P060352_reissue.html
156a044948f18c8648c6c1a8a6d715077b8eb105e35f0190b63a34a5e7984073  certificates/individual/DRAFT_CoQ_P060362_reissue.html
45aadec10106c6210b85fe33f714a10e984e63690f01cec33804a59ff5267608  certificates/individual/DRAFT_CoQ_P060372_reissue.html
2295dc40aa708806459a2040b2ac634f33e262e660c380ccf51ba31b6916556b  certificates/individual/DRAFT_CoQ_P060382_reissue.html
fc2ae53c27b8a9ffda96f54650718b409f7b8744579068bd26f4ab53243c883e  certificates/individual/DRAFT_CoQ_P060402.html
aa39d58aba21f1ed0533af6750a9a77d82ba5ba797a2296f3e6ec5a7af12639e  certificates/individual/DRAFT_CoQ_P060402_reissue.html
0fef2218d7176418ba4e7fb24508d3dc0b6a8bd79f17a0eed09a7ca5fc6d3b69  certificates/individual/DRAFT_CoQ_P060412_reissue.html
90f43941971396ad61c57ef818fc50184f4adb38b009c0d5db3b6874b3b7dea9  certificates/individual/DRAFT_CoQ_P060422_reissue.html
25d5569adffd4ceffac402528482ada4ccdbf52481d7d1a3db0489747e99ec82  certificates/individual/DRAFT_CoQ_P060492_reissue.html
e396d0e21fe89a186e879f11a0d8267940a6316b3a855903114856b3c47b002a  INDEX.html
118e68e675dcef522dabb6b0232ad64836db0df8a63d397fb0fda61488394f60  certificates/Tranche_1_2_CoQ_Draft_Set.html
5f1596567050490a28eef98716d82fbe5b7ecc8e7339595e6bb20c5074446089  certificates/Tranche_1_2_CoQ_Reissue_Draft_Set.html
22aa2d3ef2595fc328b027ae782300c637dc76d186a8d69196cdd12730fc8e99  compilation/CoQ_compilation_v35.xlsx
86f318d830c5ea9384ecc7514a5256385c0be951b2155c3e7b15d1f18ae6abf1  compilation/CoQ_compilation_v35_wide.csv
9cf19e8c4222f5a5c4d8a61dfb398dd7977471817575f9e44cf4d9fa6e687e17  compilation/CoQ_compilation_v35_long.csv
b67697f9a6111fad7bfc8a6877f973a9359cad2a0c9fbb2298acea1caaa25865  references/CoQ_references_v35.xlsx
07c3e6689d83a7191700831629da3a2e0b9232eb992f6b72a6df29b80b9db4fc  references/CoQ_references_v35.csv
9cde28e8c2bbfcebddcd6b725ac010e2c47eeffeb8180849962dc053292855a6  references/CoQ_references_v35.md
53f038eb89185c23b6048beaa1a76d43af228d6032a13144c02918458d831afa  references/CoQ_references_v35_nt.md
5523d1f9319133c4a57bd83fb843b706fad00e5244e4f70046230231333b1e30  workbook/CoQ_Analysis_Master_v35.xlsx
ea2ddbb9d9cd8cda204297c30159327f0a9f83bb456c47767ab145159eb3c068  desk/qc_quality_desk_artifact.html
72d1dc298f882dab8dae4114e217e73241a524cef346b927b41ea2c4e74e04a1  sources/issuance_schedule_2026-09-10.csv
22f2e9cc57bdbc1fab4a8ee8cc3146d34ee647515a5e294a9781526f79f047f9  sources/batch_dates_2026-09-10.csv
b80017375e13c7a11e543fc11a3b7cacacb50894e0e62038b1b0f047977c4ba7  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
604db64c1e818b8634205cea00f961f79e86487eaed057f301235192a39a8785  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
20f81e9311281b0682f9670c5ba8f2b2f5cc6d88de4682f77dd1855b5f346a26  sources/coq_draft_gaps.csv
01b5d3726c7e31dbef9045100bde679f678f0d7eec668fe636e4f8a5482f654d  docs/OPEN_ITEMS.md
650c132b921a4ea3e2d09d95b7c0b3394151c9f79199482e939e94a28569902d  docs/RESULT_SUPERSESSION_2026-09-16.md
f7315cbf159508aaf14c125324313e970fb7d7308364630e0ce9df67a59c3498  docs/HANDOVER_RESPONSE_2026-09-16.md
87c737d23bd53fc715e35f87c069892bc6b390bcdfc2c65d791a28f5df7e2bf7  docs/TRUTH_CHECK_2026-09-15.md
73e3b9fab72ac49d4f960aec20fbaf5b657b4d54efe2427ed156eef54d56fd64  docs/VOCABULARY_2026-09-11.md
2f86d9e6ae5800af08077c3a90d659b71e9758cfdd75a59f0511669a2ce2b7e8  docs/ISSUANCE_RULES_2026-09-10.md
101232cbe02dabe959f4ac14e3f9bdd773bfa6ff42bf2172d41b88389a7f157f  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
