# One spelling per assertion, and a verdict the desk could not read — 11.09.2026

The owner asked for the v22 workbook to be checked "in terms of the parameter
values and references". Twenty-one result columns and 1,193 references were read
cell by cell, against each other, against `Batch Dates`, the `iCoA Register` and
the `Mikro CoQ Parameter` sheet. This is what it found and what was done.

## What was already sound

Nothing in the reference layer was broken. 965 external references parse as
`CODE, (DD.MM.YYYY) [LAB]` and 228 iCoA formulas all resolve against the
register — **0 broken keys**. No document code carries two dates or two
laboratories. **0 references are dated before their lot's manufacturing date.**
Pairing is exact: 0 results without a reference, 0 references without a result,
0 results without a ✓/✗/○ mark, 0 marks without a result.

## The one that mattered

**FB032601's foreign matter was printing a pass against a certificate that says
it fails.**

CNP's ППК26127 of 21.07.2026 reports `0.08% (Не одговара)` — *does not conform*.
The figure passes the gravimetric ≤ 2.0 % limb, so CNP is failing it on another
limb of Ph. Eur. 2.8.2, leaf and stem size. The desk never saw the verdict,
because of one regex:

```python
if re.search(r"одговара|отсутн|отсуств|absent", v, re.I):
    v = "absent"
```

`Не одговара` **contains** `одговара`. The laboratory's non-conformity was being
folded into `absent`, and every judge downstream reads `absent` as a pass. The
negation is now tested first, `nonconforming()` is a named predicate with its own
doctests, and `over_limit()` gained a second limb:

> a laboratory writing *Не одговара* has already done the judging, against the
> limb of the criterion it applies, and its verdict outranks anything the desk
> can compute from the figure alone.

FB032601 now reads **OOS** on #7 and its certificate cell is **BLOCKED —
declared out of specification by the laboratory**. It cannot print `Conforms`.

## A correction to the audit itself

The first pass reported "13 results breach their acceptance criterion, all marked
✓". That was a misreading of the sheet and is withdrawn. **✓ is a coverage mark** —
a certificate is on file and its result is on the desk — not a verdict; out of
specification is carried by red bold on the result. All 13 were already flagged
correctly: 5 TYMC counts red (above 2 × 10⁴ under Ph. Eur. 5.1.4), 4 amber in the
undetermined band, and the 4 CBN values over 1.0 % are **stability timepoints**,
which the desk excludes from release judgement and names separately in STATUS.
The enforcement was right; the reading of it was not.

And the delta-HCH finding is withdrawn on the owner's confirmation: IJZ 2994/2025
reports delta-HCH at `< 0.01` mg/kg against a maximum of 0.3, the other 28
residues `н.д.`, and the page's own verdict is **ОДГОВАРА**. The result is
correctly transcribed. What survives is that the column's stated criterion is
`≤ LOQ`, which is not the Ph. Eur. 2.8.13 test — that is OI-15.

## One assertion, nine spellings

The ND ruling of 10.09.2026 had been applied to the export path and never to the
desk that feeds it, so the workbook still carried every original spelling. And
the same disease ran through five more families:

| assertion | spellings in v22 | now |
| --- | --- | --- |
| not detected | `n.r.` ×115, `н.д.` ×36, `Н.д.` ×17, `Н.Д.` ×6, `N.D.` ×1 | `ND` |
| absent | `absent`, `Одговара`, `Odgovara`, and 9 Cyrillic forms | `Absent` |
| below quantitation | `<LOQ`, `< LOQ`, `<LOQ**`, `BLQ`, `BLQ ᴰ`, … | `< LOQ` |
| conforms | `Conforms`, `Одговара`, **`Confirms`** (a typo, ×7) | `Conforms` |
| a counted colony | `×`, ` x `, `·`, `и`, `and`, `10^2` | `1.6 × 10⁴`, `< 10² and > 10` |
| a mass fraction | `0.02 ᴰ` beside `0.02 % ᴰ` | the column states the unit |

`result_vocabulary.canon()` is the single definition, applied in `values_of()` —
the one funnel every result passes through into the workbook — and on the export
path, so the workbook, the certificates and the PDFs inherit one spelling from
one place. It takes the **determination number**, because `Одговара` means
*conforms* in the identity columns and *absent* in the Salmonella and E. coli
columns and only the column can tell them apart.

It rewrites notation and nothing else. Digits, footnote markers, the ᴿ and ᴰ
markers, residue glosses and parenthetical LOQ values all survive, and a
laboratory's own verdict is preserved *as* a verdict.

**Result:** 0 non-canonical not-detected spellings remain on the tracker or the
Mikro sheet, absence collapses from 12 spellings to 3 in the workbook and **from
4 to 1 on the certificates**, and 390 printed results now come from the
controlled vocabulary.

Two things the desk was doing to itself, also fixed:

* it generated `n.r.` **itself** for a sub-determination a certificate does not
  report — the owner's reserved notation, used for something that is not a
  result. Writing `ND` there would assert the analyte was measured and absent,
  which is the one thing the cell knows to be untrue. It now says
  **`not reported`** and the notation is left to results;
* `NO-DOC-CODE (Report of Analysis)` was cited directly on Identification A and
  foreign matter for GG1024, HPA1024 and OPM1024 — an in-house result referenced
  without an iCoA, which the standing ruling forbids. All six cells now carry the
  register's own `iCoA — at issue (…)` form. **0 literal in-house references
  remain.**

## Three lots that were one lot to every join

`P160012`, `P160022` and `P160032` each printed the cultivation batch as
`— not recorded —`, so `batch_key` collapsed all three to a single key. Any join
made on the printed cultivation batch silently picked one of the three — which is
exactly what was happening between the tracker and `Mikro CoQ Parameter`, where
three parameter blocks "disagreed" that were never the same lot.

The label now names the P number inside it. The cultivation batch stays
unrecorded rather than invented (OI-10 asks for it).

**80 rows → 80 distinct keys** on the tracker and on Batch Coverage, where both
were 78. Mikro against the tracker: **0 differing parameter blocks**, from 3.

## Batch Coverage: two questions, two pairs of columns

`Certificates (n)` and `Labs present` came down from v6 and were *incremented* by
every pass that touched a lot, so they counted documents the tracker does not
cite and could not be reconciled with it — 22 rows whose count exceeded the
references (JD012603 said 7, the tracker cites 2) and 26 naming a laboratory that
appears in no reference on the lot.

The count was not wrong so much as answering a different question: it included
the 09.09.2026 documents the desk has not recorded. So the two questions now get
two pairs of columns, both derived here from the tracker rather than carried
forward:

| | |
| --- | --- |
| `Certificates (n)` · `Labs present` | what the tracker actually cites |
| `On file, not recorded (n)` · `Labs on file, not recorded` | the 09.09 documents the desk has not recorded |

**Labs present: 26 disagreements → 0.** Certificates (n): 22 → 3, and all three
are explained and recorded — GRC102501 carries two P batches in one cell (OI-11),
JD112501 and its ＊ sub-lot share three documents (OI-12), and BSS052501's DFL
report is on file twice, once per language (OI-09).

## The Open Items sheet

Fifteen findings across this session and the last are the owner's to settle, and
they were living in chat messages. `open_items.py` is the standing register —
**20 items, 17 awaiting a ruling, 3 marked on the certificate** — and it drives
both the **Open Items** sheet of the workbook and `OPEN_ITEMS.md`. Each says what
was found, what the desk did with it, precisely what is being asked, and the
evidence behind it, because *"there is a problem with the specifications"* is not
a question anyone can answer and OI-01 is.

## One more, found while checking the PDFs

39 faces in the Tranche 1 PDF and 27 in Tranche 2 embedded as **Type 3 glyph
procedures** rather than outlines — all of them Montserrat Medium Italic, while
the same family embedded as TrueType elsewhere in the same document. The count
was identical in the previously committed PDFs, so it predates this work.

The cause is one weight. `.ap-cred` sets `font-weight:600; font-style:italic`,
and the font request asked for italic at 400, 500 and 700 only. Chromium took
the nearest real italic and emboldened it, and a synthesised face has no
outlines to embed, so Skia rasterises it. Pinning the variable axes — the fix
that removed Type 3 the first time — fixed the faces the page asks for by name;
it could not fix one the page never asked for.

`1,600` is now in the request. The rule that avoids the next one: **when a rule
sets an italic weight, that weight belongs in `FAMILIES`.**

## The boundary of the ND ruling — 11.09.2026, second ruling

> *"since they're not tested, those sub-parameters are not going to enter inside
> the certificate of quality at all."*

The initial testing of a batch often runs only part of a parameter's panel:
mycotoxins assayed for **total aflatoxins alone**, with Aflatoxin B₁ and
Ochratoxin A not tested. The retest of the same batch then runs all three.

The certificate was printing a bracketed blank for each untested analyte, which
in a results column reads as a finding still to come. Before the ND ruling was
scoped it would have been worse — `n.r.` mapping to `ND`, asserting the analyte
was measured and absent.

So this is the boundary of that ruling, and both halves matter:

* `n.r.` printed **by a laboratory, as a result**, means what `n.d.` means → `ND`;
* an analyte **absent from the panel** is not a result at all → no line.

`fillCoq()` removes the row from the compiled copy. It applies **only to a
sub-determination inside a parameter that was tested** — where nothing in the
group has a result the parameter itself is missing, and that is a gap the
certificate has to show, not hide. The master file is untouched; this is the
compiled copy, the same latitude `addFitStyle` and the marker colour take. Each
compiled document records what was removed in `data-untested` on its `<body>`,
so the omission is on the page's own record rather than only in this note.

**36 rows removed across the 22 drafts — every one of them Aflatoxin B₁ or
Ochratoxin A, on the 18 release certificates whose initial panel was total
aflatoxins alone. Blank printed lines 87 → 51.**

Verified on one batch through `fillCoq` in headless Chromium, both ways:

| BG1024 | mycotoxin rows printed |
| --- | --- |
| initial release, 06.06.2026 | `Aflatoxins ∑ = < 2` |
| retest, 12-month, 17.08.2026 | `Aflatoxin B₁ = ND` · `Aflatoxins ∑ = ND` · `Ochratoxin A = ND` |

## One Macedonian word for one assertion — 11.09.2026, third ruling

> *"use Conforms | Одговара, and use the formatting convention that is set for
> the rest of the CoQ text formatting regarding ENG and MK parts."*

The results column carried **two different Macedonian words for the same
assertion**, and the page disagreed with itself:

* the desk printed **Соодветствува** on 131 results — a word that appears
  **nowhere in the master template** and on no laboratory certificate in the
  record. `build_coq_schedule.py` introduced it in two hard-coded strings;
* the master's own conformity declaration, three rows below on the same page,
  reads **"Одговара на спецификацијата"**, and every laboratory writes
  **Одговара** (and **Не одговара** for a failure — the word whose negation the
  desk had been folding away).

Соодветствува is gone from the desk. **0 occurrences remain** in the certificate
data.

And the column printed 152 results in English only beside 131 bilingual ones.
Every conformity result is bilingual now — **375 paired**. A measured number is
not translated: `20.29`, `< 2` and `ND` print as they are.

### The convention was already in the master

This is the part worth writing down. The formatting convention the owner asked
for is not a house style to be reconstructed — the master **already sets it for
this exact cell**, and nothing had ever used the rule:

```css
.r-conform .mk { display:block; font-size:6.8px; color:#5f8f74 }
```

The Macedonian belongs on its own line beneath the English, a shade smaller, in
the muted green of a conforming result. So the halves are **stacked**, not joined
by the `.bisep` pipe the master keeps for inline pairs like `TAMC | Вкупен
аеробен микробен број`. The pipe is for a label sharing a line; this cell has its
own rule. The export pairs the halves with `" | "`, `fillCoq()` splits on it, and
the master does the styling:

```html
<span class="r-val r-conform">Conforms<span class="mk">Одговара</span></span>
```

The absence rows are the one term the owner did not name: they assert absence,
not conformity. They print **`Absent | Отсутна`** — CNP's own most-used form
(`отсутна/25 g`), capitalised, rather than a term translated afresh for a
controlled document. That is **OI-23**, and it asks for confirmation.

## The page was never measured with the fonts it prints in

Pairing 375 results with their Macedonian is a line of extra height on four rows
of every certificate, and that is when the A4 page turned out never to have been
checked properly.

**"One A4 page" had been verified by reading `scrollHeight` on the page itself.**
`div.page` clips with `overflow:hidden`, so that reading returns the *clipped*
height and always answers zero. The check could not fail. Measured the only way
that means anything — inside an A4 frame, with the subset fonts the PDF embeds —
the baseline was:

| | |
| --- | --- |
| before any of today's certificate work | **5 of 22 past the bottom of the sheet, worst 72 px** |
| P060152 | printing **one** of its two approvers' signature dates; the second was off the sheet |

So this was not a regression to undo but a defect to fix. Four changes, all in
the compiled copy, none touching the master:

* **the Identification C result shortened.** It read *"Conforms — cannabinoids
  identified and quantified by HPLC"*, restating the METHOD column two cells to
  its left on the same row. That single cell stood **85 px** tall against 18 px
  for a normal row. A redundant gloss is not worth a signature (OI-24);
* **a short paired result is held on one line.** The wrapping rule exists for the
  long verbatim results; left to itself it broke `Conforms | Одговара` across two
  lines, and that second line put 15 documents that had fitted over the edge;
* **Section 03's leading closed up.** It grows one row per laboratory, and the
  lot citing four was the last one over;
* **the parameter column's leading closed up** — its two stacked lines set the
  height of every row in the table.

**5 of 22 losing content → 0.** Twenty-one fit outright; the twenty-second has a
few pixels of trailing box space past the edge with **no element beyond it**.

And the builder now measures this on every run and names any document that
overflows, because the page has very little slack left: the next thing that adds
a line will need the check. It says what it measures, too — the HTML drafts carry
no embedded fonts, so its own figure is a fallback-metric approximation and the
rendered PDF is the verdict.

## Reproducing

    python3 deliverables/qc_gap_analysis/result_vocabulary.py
    python3 deliverables/qc_gap_analysis/open_items.py --md
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=23 --icoa --cells \
        --mikro=deliverables/qc_gap_analysis/tracker/CoQ_Analysis_Master_v13.xlsx \
        --build-date=11.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026
    python3 deliverables/qc_gap_analysis/tracker/verify_workbook.py \
        deliverables/qc_gap_analysis/tracker/CoQ_Analysis_Master_v23.xlsx
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py
    python3 deliverables/qc_gap_analysis/live_instrument/build_live_instrument.py
    python3 deliverables/qc_gap_analysis/live_instrument/build_coq_drafts.py \
        --scope deliverables/qc_gap_analysis/tracker/coq_draft_scope_2026-09-10.csv \
        --chromium /opt/pw-browsers/chromium-1194/chrome-linux/chrome

**v23 verifies with 0 findings**, and the deeper pass compares **5,287 printed
results** against the certificate records with 0 findings.

---

# v24 — the standing register carries every internal certificate, 11.09.2026

The ruling of 10.09.2026, in the owner's words:

> **The register encompasses every internal certificate that exists or ever
> will**, not only what the drafted lots need. **106 certificates over 80
> batches** — one per testing round, which is exactly the number of certificates
> of quality, because a round that needs a certificate of quality needs the
> internal certificate behind it.

The desk had recorded that as an open question (OI-27) rather than as a ruling to
implement. It is a ruling. This builds it.

## What the sheet was carrying

The iCoA Register sheet printed **60 of the series' 95 certificates**. The
numbering was not the problem — where both carried a row they agreed, which
`verify_workbook.py` had been checking since the morning. The **row set** was the
problem, and a check that compares the codes of the rows a sheet happens to carry
cannot see a row that is not on the page.

| | absent from the sheet |
| --- | ---: |
| retest certificates | 26 |
| release certificates withheld as "not needed" | 9 |
| **total** | **35** |

**No retest certificate appeared at all.** The sheet's retest rows are one per lot
per sampling campaign — "Tranche 1 (sampled July 2026)", "re-analysed", "not yet
sampled" — so GP062501, which has four retest rounds and four internal
certificates, had **one row standing for four documents**. Rounds 2 and up were
not merely unnumbered; they were unaddressable, because the row key `<lot>|R`
named "some retest" and there was only one of it.

**Nine release certificates were withheld on a rule the owner has replaced.**
"Where a CNP certificate reports all three, no iCoA is needed" is the note of
05.09.2026. The ruling of 10.09.2026 is *"identification A, identification B and
foreign matter, **always**"* — they are performed in house on the packaging date
whatever an external laboratory also reports, so the certificate exists, and a
register of every certificate that exists carries it. Which document the
certificate of **quality** cites for those three determinations is a separate
question, decided by `cell_resolution`, and nothing here touches it: the 22
drafted certificates are **byte-identical** before and after.

## What it is now

The sheet **renders `icoa_register.py`** — one row per testing round, 95 codes
printed and numbered, in the order of issue. The series is the definition; the
sheet is a view of it. That is the same repair as the one made to the number
itself in the morning, applied one level up: the number had been a function of a
row's position, and the row set had been a second opinion about which
certificates exist.

Keys are round-specific for the first time. **Retest 1 keeps the bare `|R`** that
the iCoA Issuance sheet, the CoQ Register and the tracker's own in-house cells
already cite, so no lookup changes what it resolves to; rounds 2–5 take `|R2` …
`|R5`. A release round keeps its formulas — testing date from `Batch Dates`,
issue date the later of that and the SOP day — so the workbook stays live. A
**retest is dated at its own sampling, which no sheet holds**, so the series'
dates are written as literals rather than guessed by a formula over a value the
workbook does not have.

| | v23 | v24 |
| --- | ---: | ---: |
| series codes on the sheet | 60 of 95 | **95 of 95** |
| retest certificates registered | 0 of 26 | **26 of 26** |
| rows | 157 | 166 |
| addressable rounds per lot | 1 release + 1 retest | every round |

## Three defects in the desk's own checks, found by fixing the sheet

1. **The register check could not see a missing row.** It compared the code of
   every row the sheet carried and passed at 60 of 95. It now checks
   **coverage** — every certificate in the series appears on the sheet exactly
   once, and no code appears that the series does not issue. Run against v23 it
   reports the 35 that were absent, which is how a gate is shown to bite.

2. **`|R` meant "whichever retest the issue order put first".** The verifier
   built its map with `setdefault` on a bare `|R`, so GP0824_03's `|R` resolved
   to its retest **2** and the sheet's retest 1 was reported as disagreeing with
   the series it had just been taken from. The key names the round now, on both
   sides.

3. **"A legacy iCoA not on the legacy day" did not say which round it meant.**
   A legacy lot is one packed before the SOP, so its *release* certificate is
   back-dated to the SOP's day — but its *retest* is sampled in July or August
   2026 and is issued then, which is the ruling, not a breach of it. The retest
   rounds only reached this sheet today, and the check had never had to be
   precise before. It is scoped to the release round.

   A fourth, smaller one: `table()` recognised a sheet's footnote by its opening
   words — "Head of QC", "Chronological", "These corrections" — so rewriting a
   note fed its own text to `int()` as a row number. A footnote is now recognised
   by its shape: one long string spanning the table's width with nothing beside
   it.

## What it could not fix, and why

**Seven lots have no internal certificate at all** — GG1024, BSS1024_01/2,
WED102501, GRC102501, GG012601, JD012601 and SCR012601*. The cause is the
**star**. The company writes `GG012601*`; the testing record writes `GG012601`;
and `batch_id.batch_key` keeps the mark deliberately, its own docstring saying
that whether a starred lot and its unstarred namesake are the same batch *"is NOT
a question this function may answer: it is a fact about the floor"*. So the
testing record attaches to one spelling and the register row to the other, and
neither can see the other.

That is the whole of the difference between the sheet's 83 release rows and the
series' 76. The seven sit on the register unnumbered, each saying the series does
not carry it, and the question is **OI-28**: for each pair, is the starred lot
the same batch? A ruling goes in `ingestion/ecoa_runner/identity_decisions.tsv`,
which is where `batch_key` says such a ruling belongs, and the seven certificates
then issue by themselves.

## Reproducing

    python3 deliverables/qc_gap_analysis/open_items.py --md
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=24 --icoa --cells \
        --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=11.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026
    python3 deliverables/qc_gap_analysis/tracker/verify_workbook.py \
        deliverables/qc_gap_analysis/tracker/CoQ_Analysis_Master_v24.xlsx
    python3 deliverables/qc_gap_analysis/tracker/extract_artifact_data.py \
        deliverables/qc_gap_analysis/tracker/CoQ_Analysis_Master_v24.xlsx \
        deliverables/qc_gap_analysis/tracker/v24_data.json "CoQ Parameter Tracker v24"
    python3 deliverables/qc_gap_analysis/tracker/build_artifact_page.py \
        deliverables/qc_gap_analysis/tracker/v24_data.json

**v24 verifies with 0 findings**, the deeper pass compares **5,341 printed
results** against the certificate records with 0 findings, and the 2,330
recalculated formulas produce **0 error values**.

---

# v25 — the workbook says what has been ruled, 11.09.2026

The Read Me sheet's own VERSION HISTORY stopped at v11 and its RULINGS IN FORCE stopped at
05.09.2026 — nine versions and six days of built, verified, pushed work that the workbook
never wrote down about itself. A person opening `CoQ_Analysis_Master_v25.xlsx` cold, reading
only its own Read Me, would not learn that the register is standing, that an analyte never
tested does not appear on a certificate, or that a laboratory's own non-conformity is read as
one. Extended through v25, both sections, from primary sources: the git history for what each
version actually built, `ISSUANCE_RULES_2026-09-10.md` and `VOCABULARY_2026-09-11.md` for the
rulings' own wording.

## Two findings that were written down once and then left

Auditing for rulings not reflected in the workbook surfaced two findings that exist in this
folder's own prose but never reached the standing register:

* **OI-30 — the Loss on Drying method line is uniform across every lot.** The ruling of
  10.09.2026 says the certificates should attribute the method each lot was actually tested
  by (German pharmacopoeia, < 10 %, before the Ph. Eur. cannabis monograph 3028; the Ph. Eur.
  method, ≤ 12 %, after). The printed method line has always been the latter, for all 80
  lots. The one lot whose own numeric result sits where the two criteria disagree —
  J31122501, 10.30 % — was already investigated and resolved on 31.08.2026: the certificate
  prints its own limit as `< 12`, so `≤ 12.0 %` is that certificate's own specification, not a
  substitution. What remains unverified is the method TEXT on the other ~94 lots, because no
  certificate's own method paragraph is in the desk's record — only its number.
* **OI-31 — six batches are silently filed under one strain name.**
  `DELIVERY_RECONCILIATION_2026-09-07.md` records, and never closed, that the desk files GG4
  (GG012601, GG012603, GG112501) and Gorilla Glue (GG1024, GG1024_01, GG1024_02) under one
  strain name while the delivery sheet keeps them apart — unlike its six siblings in the same
  finding, which all print on the Work Order as "strain name unruled." Today's iCoA Issuance
  sheet prints all six as `Gorilla Glue`, a merge nobody ruled on. No certificate is wrong
  today because none of the five non-`GG1024` lots carries a specification at all (OI-03) —
  but the day one is filed under either name, the merge decides the other five by default.

Neither is fixed by guessing. `strains.py`'s own rule is to repair a missing space (decides
nothing) or list a letter-for-letter disagreement for a ruling (decides nothing either) — not
to merge two names that differ in their letters, which GG4 and Gorilla Glue do.

## One item shortened, not because it closed by ruling

OI-14 named three placeholders; Identification C's document sourcing is built —
`_pick(4, False) or _pick(3, False)` resolves it on all 22 drafts, 0 falling back to the
unresolved message — so the clause is folded out rather than left to read as still open. The
other two (the approvers' names, the potency range) are still the master template's specimen
and still open.

## Reproducing

    python3 deliverables/qc_gap_analysis/open_items.py --md
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=25 --icoa --cells \
        --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=11.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026
    python3 deliverables/qc_gap_analysis/tracker/verify_workbook.py

**v25 verifies with 0 findings**, the deeper pass compares **5,341 printed results** against
the certificate records with 0 findings — unchanged from v24, because nothing here touches a
certificate: `coq_artifact_data.json` and every drafted certificate are byte-identical before
and after.

# v26 — seven tabs, not sixteen, 14.09.2026

The owner, 14.09.2026: "Do we need all of those chips? I really need just these" — Batch
Coverage, the tracker, iCoA Register (with iCoA Issuance inside it), Batch Dates, CoQ
Register, Parameters — "or you can put all those formula calculating misc in one sheet?"

## What moved

The **iCoA Issuance** sheet is gone. It was one row per batch and round, which is exactly what
the iCoA Register is, so its eleven columns that the register did not already carry (basis
date, harvest, packaging, planned CoQ issue, the three in-house results, identification C's
eCoA, the retest assay and mycotoxin eCoAs, carried-forward) are now register columns. Nothing
looked the issuance sheet up by formula — the register was always the lookup target — so no
key changed. The register's `Key` column moved from P to AA; `REG_KEY_COL` is now asserted
against `REG_COLS` at build time, because a formula matching the wrong column would resolve
silently to the wrong certificate.

Ten sheets — Read Me, Delivery T1–T3, ImB Register, Mikro CoQ Parameter, Reconciliation
09.09, Credit Audit, Credit Corrections, Work Order, Open Items, Summary Dashboard — are now
sections of one **Reference** sheet (817 rows), each under its own title in capitals. Nothing
was deleted: none of them is a formula source, but they are the audit trail.

## Where a section ends is recorded, not guessed

The first fold marked section boundaries by a two-row blank gutter, and the reader looked for
that gutter. Reconciliation 09.09 separates its *own* sections with the same gutter, so the
reader stopped at the first inner one and the sheet lost its last section — "CLOSURES THAT
FOUND NO ROW", eight rows — silently. `fold_reference_sheet` now writes a defined name
`_fold_<slug>` per section with its exact row range, and `reference_sections.py` reads that.
Every consumer (verify_workbook, verify_prose, extract_artifact_data) goes through
`sheet_or_section`, which returns the sheet if it still exists and a view onto its section if
it does not, so no check had to learn where its table went.

## Eleven false sentences found by running a checker that had never run

`verify_prose.py` — the third pass, what the sheets *say* — defaulted to v11 and was not in
CI, so it had been checking a workbook that stopped shipping on 09.09. Pointed at v25 it
reported eleven findings, all also in v24. Three were the workbook's:

* The CoQ Register note said the legacy series is issued on **27.05.2026**; the rows issue on
  06.06.2026 (`--legacy-coq`, the owner's date). The note was a literal. Both register notes
  now take their day from the same value the rows do.
* An uncredited in-house reference on the tracker read `iCoA-PP_26-004, (11.04.2025) [PP]`
  with no "on file, not credited" — the register-lookup formula dropped the suffix that
  every literal reference carries. The grey fill and the STATUS count were right; the text
  was not. Four lots.

Eight were the checker's. It judged coverage by whether a reference opened with an em dash,
which is the shape of every in-house result (`— at issue —, (16.02.2026) [PP]`) — so it
uncounted identification A, B and foreign matter on every lot and read the STATUS cell as
undercounting when the cell was right. It now reads the fill, which is the tracker's
definition and `verify_workbook.py`'s. It compared the legacy day against a literal of its
own (15.05.2026) rather than the note, so it held a third copy of the date; it found the
note by its opening words, so the register's rewritten note returned "" and every check on it
passed on an empty string. Both fixed; the check is in CI.

Two more of the same shape, found on the way out. The register **Status** strings said
"issued 27.05.2026" and "issued with the legacy series on 15.05.2026" — literals again, on
rows that issue on 06.06 and 03.06; they take the series' day now, and `verify_prose` holds
every Status that names a day to the row's own issue date. And `build_delivery_package.py`'s
`STAMP` was `"2026-09-11"`, so a rebuild on the 14th overwrote the 11th's archive under the
11th's name; the archive is stamped with the build date the workbook states about itself.

## Truth check of the fold, 14.09.2026 afternoon

The owner asked for another truth check. The three gates were green; the question was what
they do not test — whether the fold and the register merge preserved everything. An
independent pass compared v25 to v26 cell for cell: every folded sheet is identical in value,
style, merged range and formula result at its place on Reference; no formula anywhere names a
folded sheet; every value the old iCoA Issuance sheet carried is on a register under the same
batch and round (its CoQ plan reference on the CoQ Register, its own row number nowhere —
that was a position, not a fact). Four things it found that the gates could not:

* **The registers never asked `strains.py`.** `apply_strain_rulings` covered Batch Coverage and
  the Delivery sheet and nothing else, so both registers printed the certificate register's
  own spelling — `Cup Junky` and `Cap Junkie` on eight lots against the Head of QC's ruling of
  07.09.2026, `GorillaGlue`, `FatBastard`, `GrapePie` unspaced. The one sheet that printed the
  ruled spelling was iCoA Issuance, and folding it away took the ruling out of the workbook
  with it. Both registers and the preliminary registers workbook now go through the rulings;
  every strain on the register is canonical, and the unruled pairs print on the Work Order.
  `strains.py` repairs a missing space only for names on its known list, which had
  `GorillaGlue` and not `CashCow` or `JellyDonutz`; both added — a space repair decides
  nothing, and Jelly Donuts / Jelly Donutz stays an unruled conflict on the Work Order.
* **One register row said "not needed".** JD012603/01 (P060362) printed `not needed — CNP
  covers A, B and foreign matter`: the note of 05.09.2026 that the ruling of 10.09.2026
  ("identification A, B and foreign matter, always") replaced. The row exists because the
  plan of 31.08.2026 schedules its certificate; the series does not carry it because the batch
  has no entry in the owner's release register, so `icoa_register.py` has no testing history
  to number — packed 23.05.2026, a CoQ planned with 21.01 % THC, and absent from the register
  it should be in. Nothing on either register says "not needed" now; a row the series does
  not carry says why, and this one says that.
* **The preliminary registers workbook said two false things** on its Read Me — built "on
  05.09.2026" (a literal; it now states the build date) and sourced from "sheets iCoA
  Issuance and Batch Dates".
* **The Read Me's version history stopped at v25**, and OI-31 still described the iCoA
  Issuance sheet. Both brought forward. **OI-32** added: the thirty Tranche 3 Farmahem
  227-K/26 potency retests on file and in no record, twenty-five prepared and not written,
  five held on batch identity — a finding that had been living in chat.

What the fold does lose, and cannot help: each folded sheet had its own frozen header row and
six had an autofilter. One sheet has one of each, so the Reference sections have neither.

## Reproducing

    python3 deliverables/qc_gap_analysis/open_items.py --md
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=26 --icoa --cells \
        --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=14.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026
    python3 deliverables/qc_gap_analysis/tracker/verify_workbook.py
    python3 deliverables/qc_gap_analysis/tracker/verify_prose.py

**v26 verifies with 0 findings**, the deeper pass compares **5,341 printed results** with 0
findings, the prose pass compares 430 Mikro cells with 0 findings; 36,373 recalculated cells,
0 formula errors. `coq_artifact_data.json` and every drafted certificate are byte-identical
before and after — nothing here touches a certificate.

Still not in v26: the Tranche 3 Farmahem `227-K/26` retest results. Their register write is
blocked on permission and five of the thirty are held on batch identity (OI-28).

# v27 — the Tranche 2 mycotoxin certificates, 14.09.2026

Thirty-two Farmahem reports of analysis, `220-1-М/26` … `220-32-М/26`, read directly from
the rendered pages at the owner's request and cross-checked page by page against an
independent Gemini read (32 of 32 agree); every result ND. Everything about the intake —
the reads, the placement, the two writes (`apply_220M.py` into the release register,
`instances_220M.py` into `new_instances.json`), the two definition gaps the first build
exposed, and the numbers v27 shows — is in `intake_220M_2026-09-14/README.md`.

What matters for the vocabulary: **a certificate's family label and its retest status are
one definition.** `family()` used to name the 197- series alone while `is_reanalysis()`
knew 220- too, and the tracker files a retest by the label — so the 32 certificates
reached the schedule and the registers and never the tracker. The label now derives from
`REANALYSIS_SERIES`, which also carries the 227- potency series (owner, 12.09.2026).

And one latent defect closed, with a gate for it: eight lots' in-house cells keyed another
lot's internal CoA because the at-issue placeholder names its lot in a parenthetical that
`nkey()` strips. `verify_workbook.py` check 7b fails v26 on 27 cells and passes v27.

## Reproducing

    python3 deliverables/qc_gap_analysis/intake_220M_2026-09-14/apply_220M.py
    python3 deliverables/qc_gap_analysis/intake_220M_2026-09-14/instances_220M.py
    python3 deliverables/qc_gap_analysis/build_coq_schedule.py
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py
    python3 deliverables/qc_gap_analysis/open_items.py --md
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=27 --icoa --cells \
        --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=14.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026
    python3 deliverables/qc_gap_analysis/tracker/verify_workbook.py
    python3 deliverables/qc_gap_analysis/tracker/verify_prose.py

The first of those writes the owner's register, which this environment may not do on its
own (refused twice on 14.09.2026), so v27 was built from a copy of the tree with the two
writes applied, and the repository still carries the v26 workbook, on which the new check
7b reports the 27 cells above until the register is written and v27 built in place.

# v28 — the retest sampling dated, the retest series issued, 15.09.2026

Four rulings of 15.09.2026, and what each one is in code:

* **The retest campaigns were sampled on dates the owner set.** `sampling_dates.py` is the one
  definition: Tranche 1 on 21–24.07.2026 (Tuesday to Friday of the week 25.07 falls in,
  6/5/5/5 by certificate number; Farmahem received the samples 27/29.07), Tranche 2 on
  12–14.08.2026 (11/11/10; received 17.08), Tranche 3 on 19–21.08.2026 (10/10/10; received
  24.08). A campaign's internal certificates are all issued three days after its last sampling
  day: 27.07, 17.08, 24.08.2026. A batch's sampling day follows its certificate's running
  number, a fact the certificate carries.
* **A re-analysis certificate is never release testing.** `testing_series.rounds()` places every
  197-, 220- and 227-series certificate in a campaign round of its own, after the rounds the
  rest of the record makes; the release round may be empty. `REANALYSIS_SERIES` and
  `is_reanalysis()` moved there from `build_coq_schedule.py`, which imports them — one
  definition. Sixteen batches whose register block holds nothing but a campaign certificate
  now have a retest round, and seven Tranche 1 lots under a P-number-only block have theirs.
* **Identification A, B and foreign matter are performed on every batch, and every CoQ cites
  the internal certificate for them.** `icoa_register.py` emits a release row for every batch
  (an empty release round included) and numbers a round whose packaging date the list does
  not hold, with the testing date not stated. A campaign round is tested on the sampling day
  and issued on the campaign's day; the tracker's internal-certificate day is now the same
  arithmetic (it was "5 working days after packaging complete" there alone).
* **A reissue prints every parameter.** `build_coq_schedule.py` carries the initial
  certificate's row — result, document, date, laboratory, and its status — for every
  determination outside the retest scope (`ST_CARRIED`); the export re-cites the release
  round's internal certificate where the carried row rests on an in-house record, and a
  carried row neither dates the reissue nor lifts its 12-month floor.

And the reissue is numbered by the same rule as the release certificate: 7 days after the
last certificate it cites, never before its internal certificate, in date order with the
release series, once the retest assay, the mycotoxins and the internal certificate exist.
Tranche 1's 21 reissues take CoQ-PP_26-083 to -103 on 17.08.2026; Tranche 2 waits for its
potency certificates and Tranche 3 for its mycotoxin certificates, and the CoQ Register says
so per lot. A tracker row holding several P lots reads its campaign per lot from the series,
not from the document pool the lots share, and a reissue needs its assay and mycotoxins
from ONE campaign.

`cnp_methods.py` reads off every CNP certificate which pharmacopoeial method it reports:
DAB (Deutsches Arzneibuch 2018) on every certificate from ППК25050 (26.02.2025) to ППК26069
(11.05.2026), Ph. Eur. 3028 from ППК26110 (30.06.2026). A CoQ row citing a DAB certificate
for #3–#6 or #8 prints the DAB reference (`mth` in the export), and the Parameters sheet says
so. `receipt_dates.py` reads the date each external certificate says the laboratory
admitted the sample — 335 certificates, from the certificate texts and the page reads — and
`coq_references.py` carries it beside every cited certificate, with the sampling day, and
paints every `n/t` cell red with a list for the owner's check.

One defect found on the way: the export consulted `issuance_schedule.py` and
`icoa_register.py` on the PREVIOUS build's `coq_artifact_data.json`, so an intake numbered
and dated nothing until the build after it. It now writes a preliminary export first and
reads that.

## Reproducing

    python3 deliverables/qc_gap_analysis/intake_220M_2026-09-14/apply_220M.py
    python3 deliverables/qc_gap_analysis/intake_220M_2026-09-14/instances_220M.py
    python3 deliverables/qc_gap_analysis/intake_227K_2026-09-15/apply_227K.py
    python3 deliverables/qc_gap_analysis/intake_227K_2026-09-15/instances_227K.py
    python3 deliverables/qc_gap_analysis/cnp_methods.py
    python3 deliverables/qc_gap_analysis/receipt_dates.py
    python3 deliverables/qc_gap_analysis/build_coq_schedule.py
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py
    python3 deliverables/qc_gap_analysis/icoa_register.py --csv
    python3 deliverables/qc_gap_analysis/issuance_schedule.py --csv
    python3 deliverables/qc_gap_analysis/open_items.py --md
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=28 --icoa --cells \
        --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=15.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026
    python3 deliverables/qc_gap_analysis/tracker/extract_coq_register.py \
        deliverables/qc_gap_analysis/tracker/CoQ_Analysis_Master_v28.xlsx
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py      # the register codes
    python3 deliverables/qc_gap_analysis/coq_references.py --out deliverables/qc_gap_analysis/intake_227K_2026-09-15/CoQ_references_v28
    python3 deliverables/qc_gap_analysis/tracker/verify_workbook.py
    python3 deliverables/qc_gap_analysis/tracker/verify_prose.py

# v29 — the references table inside the workbook, 15.09.2026

The owner asked for the references table and its n/t list "inside the v28 workbook". A
workbook with two more sections is a new build, so it is v29; nothing else changed. The
`CoQ References` tab is `coq_references.py` run inside the build (`build_rows` /
`fill_sheet`), with the CoQ code taken from the `CoQ Register` tab of the same workbook —
keyed to its rows — rather than from the export's copy of an earlier register, so the two
tabs cannot disagree. Every n/t cell is red, and `Not Tested Review` is a section of Reference
listing them (certificate, batch, series, determination, the cell as printed). The
`Potency Grades` tab (owner, 15.09.2026: "include this information inside the workbook")
renders `potency_grades_2026-09-15.csv`, which `potency_grades.py` parses off the Head of
QC's potency specification of 15.09.2026 (`potency_grades_2026-09-15/`): one row per strain
and grade — nominal, tolerance, specification window — with the measured results each page
rests on. The
standalone files `intake_227K_2026-09-15/CoQ_references_v29.{csv,md,xlsx}` and
`CoQ_references_v29_nt.md` are the same table written by the same code from the command
line, after `extract_coq_register.py` has lifted the v29 register into the export.

    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=29 --icoa --cells \
        --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=15.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026

Two more columns groups on the `CoQ Register` in the same build (owner, 15.09.2026): a reissue
names the **initial certificate it supersedes** by the register's own code, looked up by Key
so it follows a renumbering (n/a on an initial certificate); and every certificate carries
its **potency grading** — the Total THC result it prints and the certificate it comes from,
the grade of the potency specification of 15.09.2026 whose window it falls in (nominal ±
tolerance, grade numeral from the highest nominal down), and the product code
`{ABBR}_THC{nominal} : CBD1` and specification document code `QCSP_001_{ABBR}-{numeral}_v.NN`
generated from it. `potency_grading.py` is the one definition: the strain from the batch
code's letters (else the strain name through the rulings), the window as printed, and the
version rule — v.01 cited where a specification with that product code is issued, "to issue"
where none is, v.02 where the numeral is issued for another nominal, because the
specification of 15.09.2026 changed the grade set of several strains. A result in no window
is graded to the nearest window and the Grading note says so.

**Correction the same day (owner, 15.09.2026): every grade, nominal, tolerance and range already in
the issued specifications, the issue plan and the certificates is old and potentially wrong; the
potency specification of 15.09.2026 is used exactly, everywhere.** `build_coq_schedule.py` no
longer takes the Total THC criterion, grade, product code or specification document code from
the issue plan or the issued QCSP 001 v.01: each certificate's criterion is the window its own
Total THC result falls in (the release result on the release certificate, the re-analysis on the
reissue), and the product code and the specification code are generated from it. The v.01
document is cited only where it carries the same product code and the same window; a numeral
issued with any other content takes v.02 and the status says what it supersedes; a numeral never
issued takes v.01 (to issue). The issued v.01 document is recorded beside the generated code
(`issued_spec`, `spec_conflict`), not used. The specification attributes — phenotype, chemotype,
processing, packaging — are the strain's and are read off any issued specification of the same
strain. The desk artifact and the 22 draft certificates were recompiled from the new export;
v29 was rebuilt in place.

**And no second version (owner, 15.09.2026):** every specification document code is v.01 —
the initially issued specifications were wrong, and this is not the official issuing of the
document; the set goes for review. `potency_grading.spec_code()` returns
`QCSP_001_{ABBR}-{numeral}_v.01` always, and the status beside it records, for that review,
what the v.01 already issued under the same strain and numeral printed ("replaces the issued …",
"same as issued", or "new").

**Sequential numerals (owner, 15.09.2026: "I choose sequential naming of specification
grades").** The grade numeral of a strain is an ordinal of definition, not of potency: the
grades the potency specification of 15.09.2026 lists are numbered in the order that table
prints them (the first table by nominal descending, so it reads as before) and frozen in
`potency_grades_2026-09-15.csv`, column `numeral`; `potency_grades.number()` assigns a grade
added later the strain's next free numeral whatever its nominal, and never renumbers one that
is frozen. So `QCSP_001_BSS-II_v.01` is not below or above `-I`, only defined after it. A
result that falls in no window of its strain gets no grade: `potency_grading.grade_of()` returns
"new specification required — X % is in no window of ABBR (nearest …); nominal and tolerance to
define, numeral N", with the strain's next numeral reserved, and the CoQ Register prints that
note in its Grading note column. In this build no result falls outside every window, so the
rule changes no code; it fixes what happens the day one does.

**The compiled certificate names what the register states (owner, 15.09.2026).** `fillCoq()`
prints the document code the `CoQ Register` states (`regcode`) in the header's Document ID
line — the same rule as the date of issue since 10.09.2026; a certificate the register has not
numbered keeps the controlled blank `CoQ-PP-····-····`. A reissue prints, under its date of
issue and in small bracketed type, `(supersedes <code> of <date>)` — the initial certificate of
the same lot by the register's own code and its date of issue (`export_coq_artifact_data.py`
writes `supersedes` on every additional-testing record from the initial record of the same
batch key). `build_coq_drafts.py --series reissue` compiles the 12-month reissues of
`tracker/coq_reissue_scope_2026-09-15.csv` (`live_instrument/reissue_scope.py` writes it from
the export: the 21 numbered Tranche 1 reissues draftable, every other reissue listed with the
reason it is not) into `drafts/DRAFT_CoQ_<lot>_reissue.html`,
`Tranche_1_CoQ_Reissue_Draft_Set.html` and `coq_reissue_draft_gaps.csv`, reading the code, the
date and the supersedes line back off every compiled page; `print_coq_pdfs.py --series reissue`
prints them to `Tranche_1_CoQ_Reissue_Drafts.pdf`.

    python3 deliverables/qc_gap_analysis/live_instrument/reissue_scope.py
    python3 deliverables/qc_gap_analysis/live_instrument/build_coq_drafts.py \
        --series reissue --scope deliverables/qc_gap_analysis/tracker/coq_reissue_scope_2026-09-15.csv
    python3 deliverables/qc_gap_analysis/live_instrument/print_coq_pdfs.py \
        --series reissue --scope deliverables/qc_gap_analysis/tracker/coq_reissue_scope_2026-09-15.csv

# v30 — the Tranche 2 potency certificates, and every batch on record in the schedule, 15.09.2026

The owner asked why CoQ Register rows 105–173 of v29 had no code, and answered the reason
himself: "they are all contained in the database … here are all retest results that I have on
file and correct yourself." The thirty-two Farmahem reports `220-1-К/26` … `220-32-К/26` — the
Tranche 2 re-analysis of cannabinoids, received 17.08, analysed 24/25.08, issued 25/26.08.2026
— had been in `eCoA_DATABASE` since 09.09.2026 and the desk had never taken them in as the
retest assays. `intake_220K_2026-09-15/` is the intake (two independent page reads, 32 of 32
agreeing on batch, dates, sample number, results and uncertainty; `apply_220K.py` writes the
register rows into existing blocks only; `instances_220K.py` the tracker instances;
`receipt_dates.py` reads the receipt date as its fifth source). With the assay on file beside
the 220-М mycotoxins, the Tranche 2 reissues are issuable under the owner's rules of 31.08 and
10.09: **thirty Tranche 2 reissues numbered CoQ-PP_26-104 … 133, planned 18.09.2026** (the first
working day 7 days after the latest certificate cited, 220-М of 11.09.2026), after the 82
initial certificates and the 21 Tranche 1 reissues of 17.08.2026. The Tranche 3 reissues still
wait: no 227-М mycotoxin certificate exists on any list the owner has provided.

Two definitions had to move for the numbers to be right.

**A tracker document belongs to one lot.** Three lots of JD012603 (P060362, P060412, P060422)
and two of GRC102501 (P060142, P060182) share one cultivation batch, and the tracker filed
every document of the batch in one pool — so a sister lot's certificate could be cited as a
lot's retest, and in v29 `220-16-М/26` was cited by all three JD012603 lots. `DOC_LOT` now
records the P lot of every certificate — from the instance that attaches it, and for every
certificate of a release-register block from the block's lot (or the batch list's lot for the
block's cultivation batch) — and the register part cites, for a lot, only documents of that
lot or of no lot. Each JD012603 lot now cites its own 220-16/17/18-К and -М.

**Every batch on record has its place in the schedule.** `build_coq_schedule.py` built its
placeholder lots from the iCoA issuance list of 31.08.2026, which predates the blocks the
intakes opened: JD042601 (P060492) on 09.09 and the sub-lot blocks BSS1024_01/2 (P050142),
WED102501 (P060102), SCR012601 (P060342), GRC102501/1 (P060142) with their 227-К re-analyses on
11.09 — five blocks with certificates on file and no CoQ in the export at all, so no reissue
row on the register (FB042601 and CC042601 had a release row from the tracker and no reissue).
Every register block outside the plan and the list now gets a predicted release and reissue,
dated from the batch list's packaging date: 178 CoQs in the export, 180 rows on the register.
JD042601's Tranche 2 reissue is numbered with the others; the four 227-К lots wait with
Tranche 3.

**And a reissue is numbered after the certificate it supersedes, never before it.** FB042601
and CC042601 have their Tranche 2 assay and mycotoxins on file but no packaging date on the
list, so the register withholds their release CoQ — and now withholds the reissue with it
("initial certificate withheld"), where the first v30 build had numbered the reissue of an
unnumbered certificate.

Both registers audited on the recalculated workbook (`audit_registers.py`): iCoA Register 184
numbered contiguous 1..184; CoQ Register 133 numbered contiguous 1..133, codes equal to their
numbers, dates non-decreasing, every numbered CoQ citing a numbered iCoA dated on or before it,
all 51 numbered reissues after every initial certificate and naming the one they supersede by
the register's code. `verify_workbook.py` and `verify_prose.py`: no findings. 53 reissue
drafts compiled (21 Tranche 1, 30 Tranche 2 — including the two withheld lots, which print the
at-issue placeholder where the code goes), every one printing its register code, date and supersedes line;
`Tranche_1_2_CoQ_Reissue_Draft_Set.html` replaces the Tranche 1 set,
`Tranche_2_CoQ_Reissue_Drafts.pdf` is new. One result still prints outside its band on the
reissue set (GG1024, LoD 76.07 — the open item it was).

## Reproducing

    python3 deliverables/qc_gap_analysis/intake_220K_2026-09-15/apply_220K.py --register <register>
    python3 deliverables/qc_gap_analysis/intake_220K_2026-09-15/instances_220K.py
    python3 deliverables/qc_gap_analysis/receipt_dates.py
    python3 deliverables/qc_gap_analysis/build_coq_schedule.py
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=30 --icoa --cells \
        --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=15.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026
    python3 deliverables/qc_gap_analysis/tracker/extract_coq_register.py tracker/CoQ_Analysis_Master_v30.xlsx coq_register_2026-09-10.csv
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py
    python3 deliverables/qc_gap_analysis/live_instrument/reissue_scope.py
    python3 deliverables/qc_gap_analysis/live_instrument/build_coq_drafts.py --series reissue \
        --scope tracker/coq_reissue_scope_2026-09-15.csv

# v31 — the Tranche 3 codes allocated, the retest programme the QP's, 15.09.2026 (evening)

Three rulings from the owner the same evening, after v30 was delivered.

**"You can even now allocate the certificate of quality document codes for Tranche 3."**
The Tranche 3 reissues stood without a code because no 227-М mycotoxin certificate exists
yet; but every Tranche 3 retest parameter is tested at Farmahem and its certificates all
issue on one date, so the codes can be given now. Then: the analyses complete within ten
days, likely by Friday 18.09.2026, and all Tranche 3 certificates issue on one day, "let's
say Monday next week" — and the series must stay chronological. In the register
(`build_tracker_v8.py`): a Tranche 3 reissue whose release certificate is numbered takes the
next code after the last Tranche 2 reissue, in the same order rows of one day are given
(cultivation batch, then P lot); `Issuable` reads **`allocated`** — never `yes` — `No.` counts
it, and the planned date is the owner's, **21.09.2026** (`--t3-issue=21.09.2026`), provisional
until the 227-М certificates exist, which the rule-date cell and the Status say. **28
allocated, CoQ-PP_26-134 … 161**, every one dated after the last Tranche 2 date (18.09.2026),
so the chronology the numbering promises holds. The compiled certificate prints the allocated
code (the register's, as since 15.09.2026), and `reissue_scope.py` refuses to draft a reissue
whose register row is `allocated` rather than `yes`: the export carries `reg_issuable`
beside `regcode`, so a code is never mistaken for an issue. The first attempt tested the
date instead of that field and compiled 28 Tranche 3 drafts with no mycotoxin result on
them; the field is the definition now.

The two Tranche 3 lots whose release certificate the register withholds (GG012601＊,
JD012601＊ — no internal certificate, OI-28) keep their reissue unallocated with it: a reissue
is never numbered before the certificate it supersedes.

**One Tranche 3 lot had no reissue row at all.** `227-29-К/26` is BSS1024_01/1 (P050122); the
31.08 iCoA list spells the batch BSS1024_01 and the schedule's placeholder for it carried no
P lot, so the tracker — which finds a lot by its P number where the cultivation batch is
spelled with a sub-lot on one side and without on the other — never found the reissue. A
placeholder now takes its register block's packaged lot (`_block_lot`), which also makes the
export say P050212 for CJ062501/2 rather than the bare cultivation batch: its Tranche 1
reissue draft is `DRAFT_CoQ_P050212_reissue.html` now, the lot the register keys it by.

**"For all the production batches that are not listed into Tranche 1, 2 or 3, those are not
subject to a retest as of yet."** Only the tranche batches are for sale, so only they were
retested at the QP's request; the rest get their release certificate — the final quality
control testing before packaging — and nothing more. The schedule had treated the retest
programme as universal (every batch a predicted reissue a year after release). It now gives a
reissue only to a lot whose register block holds a campaign re-analysis certificate (197-,
220-, 227- series, `is_reanalysis`), which is the mark of a batch the QP had sampled. Six
batches lose the predicted retest row they carried on v30 — JD022601 (P060482), FB032601
(P060452), GG032601 (P060462), P160012, P160022, P160032 — on both registers; the iCoA Register
keeps its 184 numbered rows and the CoQ Register is 82 initial + 21 Tranche 1 + 30 Tranche 2 +
28 allocated Tranche 3, then the batches the tranches do not cover, lot by lot, none of which
can take a code before its external results and its packaging exist.

## Reproducing

    python3 deliverables/qc_gap_analysis/build_coq_schedule.py
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=31 --icoa --cells \
        --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=15.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026 \
        --t3-issue=21.09.2026
    python3 deliverables/qc_gap_analysis/tracker/extract_coq_register.py tracker/CoQ_Analysis_Master_v31.xlsx coq_register_2026-09-10.csv
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py
    python3 deliverables/qc_gap_analysis/live_instrument/reissue_scope.py
    python3 deliverables/qc_gap_analysis/tracker/verify_workbook.py CoQ_Analysis_Master_v31.xlsx

# v32 — the truth check, 15.09.2026 (evening)

The owner asked for a truth check of the parameter results and the eCoA codes, dates and
laboratories the desk cites. `tracker/truth_check_2026-09-15.py` is an **independent code
path** — it imports none of the schedule, the export, the tracker builder or the verifier —
that reads the primary records (the release register with the intakes applied, the intake
transcriptions and their second reads, the two-read corpus, the 09.09 pass, the tracker
instances) with its own key and value normalisation and compares, forward, what every
derived layer states: the export (the certificates' rows), the tracker sheet of the
recalculated workbook, the compiled drafts, the references table and the CoQ Register.
The report is `tracker/TRUTH_CHECK_2026-09-15.md`: 94 intake certificates against their
register rows and instances (282 results each way), 1,866 certificate rows against a primary
record (1,557 results compared), 1,964 tracker citations (1,414 results), 1,497 certificate
rows against the tracker, 73 drafts (1,497 printed results, 359 cited documents), 1,549
references-table cells and 161 register rows. The first run reported 1,173 findings; 1,042 of
them were the checker's own notation gaps — `N.D.`/`н.д.`, superscripts, the tracker's ᴿ/ᴰ
markers, `Одговара (absent)`, `BLQ`, the composite in-house strings — which the desk's
controlled vocabulary already folds. What was left is what the check is for.

**Two defects on the tracker, corrected in this build (103 cells).**

* **99 mycotoxin cells read ND for an analyte the laboratory never printed.** The owner's v8
  tracker marks Aflatoxin B1 and Ochratoxin A `n.r.` on the IJZ release certificates; the ND
  ruling of 10.09.2026 folds `n.r.` into ND, and the tracker did. The page of 752/2025, read
  on 15.09.2026, prints one mycotoxin line — *Вкупни афлатоксини < 2 µg/kg* — and no B1 or OTA
  line; the release register says *not tested*; the corpus reads hold only the total. The
  mark is the owner's, not a result, and the boundary ruled on 11.09.2026 applies: an analyte
  absent from the panel is not a result. `values_of()` now renders v8's `n.r.` as **not
  reported** wherever the desk holds no result for the determination, and ND where it does
  (the Farmahem -М- certificates' total aflatoxins, ND on the register — 21 cells unchanged).
  The compiled certificates already omitted the line; the tracker and the certificates now
  say the same thing. The desk's document index also listed a column the register marks
  *not tested* as "reported"; it no longer does.
* **Four microbiology cells whose v8 value the page contradicts**, each corrected from a
  third read of the page (`tracker/value_corrections_2026-09-15.json`, applied in
  `values_of()`): 5/0008/26 TAMC **1 × 10²** (v8 and the corpus read A said < 1 × 10²; the
  register and read B were right), 9/0012/26 bile-tolerant **< 10** (v8 said 10), 471/0862/25
  TYMC **< 10** (v8 said 10), 304/0548/26 bile-tolerant **< 10² and > 10** (v8 stopped at
  < 10²). In all four the release register was right and the certificates print it.

**What the check found and this build does not change** — two open items.

* **OI-35.** The tracker does not carry the 17 documents of the 09.09 pass that eleven
  certificates print from (ППК25008 and 748/2025 for GG1024, the 031-n-К/LoD certificates of
  P060112/122/132, ten IJZ pesticide certificates), each on one page read; the tracker's cell
  for GG1024 #8 reads *— MISSING —* while the certificate prints 76.07 %.
* **OI-36.** Four two-read corpus records passed the gate with their reads disagreeing on a
  comparator, and the 09.09 pass table holds Total THC/CBD/CBN values for 197-13-К/26,
  197-7-К/26 and 197-6-К/26 that neither the register nor the two reads carry; nothing prints
  them.

The 21 findings the check still reports on v32 are these two items and the two starred lots
(JD012601＊, GG012601＊) whose register block carries no P lot (OI-28). Both registers, the
certificates, the references table and every draft: no other finding.

## Reproducing

    python3 deliverables/qc_gap_analysis/tracker/truth_check_2026-09-15.py \
        --root <qc_gap_analysis with the intakes applied to its register> \
        --workbook <recalculated CoQ_Analysis_Master_v32.xlsx> \
        --out deliverables/qc_gap_analysis/tracker/TRUTH_CHECK_2026-09-15.md

# v33 — the CoQ compilation, the first request, 15.09.2026 (evening)

The owner, recalling the request of 31.08.2026 that started the series: *"for all
certificates of quality, for all batches, for all initial and retest certificates of
quality, a table containing all information that is needed for the certificate of quality
template, but most importantly, from parameter 1 to 12, the document codes and date of
issuing of the certificate of analysis from external laboratories … and the analysis results
for each of those parameters … for every certificate of quality document code individually,
for every single one of the parameters."* He thought it was in the master workbook. It was
not, in that form: the `CoQ References` tab (v29) carries the codes, dates and laboratories
per determination, folded into one cell per parameter, and no results; the results and the
header data lived in `coq_artifact_data.json`, which is not a table anyone reads.

`coq_compilation.py` builds it from that export, with the CoQ Register's code, and the
workbook build adds it as two tabs:

* **CoQ Compilation** — one row per certificate of quality, 172 (89 release, 83 reissue):
  the template's header fields — code, series, register status, date of issue, the
  certificate it supersedes, plan number, batch, P lot, strain, harvest and packaging from
  the batch list, the template's manufacturing and packaging dates, the internal certificate
  (code, issued, tested), the retest campaign, Total THC and its certificate, grade, potency
  window, product code, specification code and status, the specification's bands
  (phenotype, chemotype, processing, dominance, packaging), the latest external certificate
  — then for every determination #1 … #12 with its sub-determinations (23) four columns:
  **result, document, issued, laboratory**. A determination the certificate prints no
  result for says why in the result column (not tested, upon request, to be performed in
  house, awaiting the Farmahem certificate) and carries no document.
* **CoQ Compilation (long)** — the same, one row per certificate and determination (3,956
  rows), with the method, the acceptance criterion, the laboratory's receipt date of the
  sample, the desk's status for the row, the route where nothing is on file yet, and the
  other documents on file that also carry the result.

The same tables stand alone as `tracker/CoQ_compilation_v33.xlsx`, `_wide.csv` and
`_long.csv`. What the compilation says is what the certificate prints — the export is the
one source of both — and the truth check now gates it: **T9** compares the wide tab and its
files with the export (172 certificates, 3,956 determination cells: result, document, date of
issue, laboratory), the long tab with the wide one cell for cell (3,956 rows), and the
workbook's tabs with the files. **No finding.** The wide table is keyed on code, series,
batch and lot, not on the code alone: nine rows share the code `— at issue —`, which is what
an unnumbered certificate carries, and only the batch and the lot tell them apart.

## Reproducing

    python3 deliverables/qc_gap_analysis/coq_compilation.py --out tracker/CoQ_compilation_v33
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=33 --icoa --cells --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=15.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026 --t3-issue=21.09.2026

# v34 — the campaign microbiology in the register, and two checks that were not checking, 16.09.2026

The owner reported that another reviewer saw inconsistencies in the heavy-metal,
microbiology and mycotoxin values for some batches, and asked whether something had been
lost across thirty-odd versions of the workbook.

**Nothing was lost.** A cross-version sweep read the tracker of every master workbook on
disk — v3 … v33, twenty with a tracker sheet — and compared each with v33 per lot and
determination, semantically rather than by spelling. Over the three families the only
substantive differences in the whole history are the **four page-read corrections of v32**
and the **n.r. → not reported ruling** of the same build; every other difference is the
controlled vocabulary rewriting notation on purpose (`<2` → `< 2`, `н.д.` → `ND`), which is
why the first, string-comparing pass reported 371 differences and the semantic pass
reported 4.

**The inconsistency was real and it was somewhere else.** The thirty IJZ-MB certificates of
the campaign sampling of 25/26.08.2026 (issued 31.08 and 01.09.2026) had been testing
instances on the tracker since 04.09.2026 and were **never rows of the release register**,
which is the one source the certificates of quality are compiled from. `OI-34` had recorded
the risk; the sweep measured it: **24 certificates of quality printed microbiology that a
newer certificate for the same lot contradicts.** P050012's printed TAMC 2.1 × 10⁴ where
the campaign certificate reads < 10; P050132's printed TYMC 3.3 × 10⁴ against < 10.

`intake_IJZMB_2026-09-16/` takes them in, through the same two-read gate as the 220-М,
227-К and 220-К intakes. **29 of the 30 are written** into the register, no block opened.
Four certificates disagreed between their two reads — every one on the bile-tolerant
gram-negative line, one read stopping at `< 10²` where the other carried `< 10² и > 10` —
and each was settled by a **third read of the page**: the fuller read was right all four
times, which is `OI-36`'s defect class with four more instances. Four more differed only in
how the laboratory spells absence (Отсутна, Отсуства, Отсуствa, Отсуствува), which the
standing vocabulary ruling already treats as one assertion.

**One certificate is held back.** `548/1079/26` is filed under P050192 (Blue Sunset
Sherbet) because its typed serial reads `PO50192`, but the page prints the strain **Sleepy
Joe** and carries a handwritten **P060192** — SJ112501, Sleepy Joy. Which lot it belongs to
is the Head of QC's to settle (`OI-37`), and a microbiology result on the wrong lot's
certificate is worse than a missing one.

**A ruling the intake exposed rather than made.** A reissue rests on its Farmahem campaign,
whose scope is the assay and the mycotoxins, so it carries the initial microbiology — the
ruling of 15.09.2026, correctly applied. Now that a later result exists, twelve reissues
will print a value a newer certificate contradicts. The twelve *release* certificates that
print the same values are not in question: a release certificate states the release
testing. The 26 rows are listed in `carried_microbiology_2026-09-16.csv` and the question —
should a reissue print the latest microbiology, sampled on a different day from the
campaign it rests on? — is `OI-38`.

**Two checks were not checking.**

* `verify_workbook`'s **check 13** claimed to compare the owner's microbiology sheet with
  the tracker. Its body was `for cu, p in LOTS: pass` — it did nothing — and it was guarded
  on a SHEET name that the fold of 14.09.2026 turned into a Reference section, so from v26
  to v33 it was skipped entirely while appearing to pass. It now compares every value the
  sheet prints against the tracker's cell for the same lot and determination and reports
  the count: **197 values compared, 0 differing**.
* **OI-13** stated that the expanded microbiology panel "has never been run" and that
  "neither is claimed on any certificate". That was false and had shipped since 11.09.2026:
  **31 certificates on file report P. aeruginosa and S. aureus**, all absent, the earliest
  from 01.12.2025. Determinations #9.6 and #9.7 print nothing on all 172 certificates. The
  item is rewritten and the question of what the certificate should print is put to the
  owner.

**One defect the intake itself caused, and the ruling that fixes it.** With the campaign
rows in the register, a lot whose block held no earlier microbiology took the campaign
certificate as its *release* result — which dated P060342's release certificate 31.08.2026
and broke the numbering's chronology. The owner's ruling already covers this, on the CoQ
Register's own note since 10.09.2026: the IJZ-MB delivery "is one campaign sampling and
every certificate in it is a retest document, for the post-SOP lots too". `testing_series`
now holds that delivery as `RETEST_ONLY` — its thirty codes frozen from the intake — and
`rounds()` never places one in the release round. It is **not** modelled as a campaign in
`sampling_dates`: its certificates issue over two days, five and six days after the
sampling, which the calendar's invariant for the three Farmahem campaigns does not admit,
and the ruling says only that they are retest documents.

| | v33 | v34 |
| --- | ---: | ---: |
| IJZ-MB campaign certificates in the release register | 0 | **29** (1 held, OI-37) |
| internal certificates numbered | 184 | **211** (89 release, 122 retest) |
| certificates of quality numbered / allocated | 133 / 28 | **133 / 28** (unchanged) |
| `verify_workbook` check 13 | skipped since v26 | **197 values compared, 0 differing** |
| `verify_workbook` / `verify_prose` findings | 0 / 0 | **0 / 0** |
| truth check findings | 21 | **21** (the same items; no new one) |

## Reproducing

    python3 deliverables/qc_gap_analysis/intake_IJZMB_2026-09-16/apply_IJZMB.py --register <register>
    python3 deliverables/qc_gap_analysis/build_coq_schedule.py
    python3 deliverables/qc_gap_analysis/export_coq_artifact_data.py
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=34 --icoa --cells --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=15.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026 --t3-issue=21.09.2026

# v35 — the supersession sweep, every determination, 16.09.2026

The Head of QC reports that a second desk, working the same job in parallel, flags
inconsistencies in **heavy metals, microbiology and mycotoxins**. v34 found and repaired a
real defect in microbiology. It found it by asking one question of every certificate:

> does it print a result that a **later** certificate for the **same lot** — one already on
> file the day the certificate issues — contradicts?

That question was asked of microbiology alone. v35 asks it of all seventeen determinations
the release register carries, over 172 certificates of quality and 93 register blocks, and
asks two neighbouring questions it raises. The sweep is
`deliverables/qc_gap_analysis/result_supersession.py`; its report is
`tracker/RESULT_SUPERSESSION_2026-09-16.md`; inside the workbook it is the **Result
Supersession** tab, one filterable row per finding, coloured by what the desk can do about
it. Nothing in the tracker, the registers, the certificates, the references or the
compilation changed — v35 adds the sweep and what it found.

## What it found

**A zero is only as good as what could be compared**, so the sweep prints its coverage
beside every one. This is where the second desk's report and the record part company:

| # | parameter | documents on file | lots with two or more | contradictions |
| --- | --- | ---: | ---: | ---: |
| #4 · #5 | Total Δ9-THC, Total CBD | 160 | 64 | 3 |
| #6 | Total CBN | 106 | 12 | **0 — a real zero** |
| #8 | Loss on drying | 75 | 4 | 4 |
| #9.1 – #9.5 | microbiology | 76 | 14 | 32 |
| #10.2 | Aflatoxins Σ | 98 | 30 | **0 — a real zero** |
| #10.1 · #10.3 | Aflatoxin B1, ochratoxin A | 54 | 1 | 0 — thin |
| #11.1 – #11.4 | Pb, Cd, As, Hg | 45 | **0** | **nothing to compare** |
| #12 | Pesticides | 46 | 1 | 0 — thin |

**No lot on file carries a second heavy-metal certificate.** Not one, over 93 blocks. So a
sweep of #11 can only ever return zero, and its silence is a gap in the record rather than
a clean result: every certificate of quality that prints Pb, Cd, As or Hg rests on a single
laboratory document, because the retest campaigns — 197-, 220-, 227- — re-ran the assay and
the mycotoxins and never the metals. Total aflatoxins, by contrast, were comparable on 30
lots and nothing contradicts; Total CBN on 12 and Salmonella and *E. coli* on 14 each, the
same. Those are zeros worth having.

Of 89 comparisons, 39 contradict, and they split in two:

* **8 are not defects.** Every one is a *release* certificate citing the *release* result
  while a later retest sits on file — the owner's ruling of 10.09.2026 working exactly as
  written: the earliest result for a parameter is the release result, and a later one
  belongs to a retest certificate, not to this one. CoQ-PP_26-007 (P050022) prints 23.79 %
  from ППК25139 of 22.05.2025 although ППК25174 of 10.07.2025 reads 23.19 %; that is the
  release certificate doing its job.
* **31 are OI-38, and OI-38 is wider than it was.** These are reissues carrying a
  determination forward from the initial testing because the campaign they rest on did not
  retest it (the ruling of 15.09.2026). 29 rows on twelve certificates are the campaign
  microbiology OI-38 already described; **two more are loss on drying** — CoQ-PP_26-093
  (P050022) carries 7.21 % where ППК25174 reads 6.51 %, and CoQ-PP_26-150 (J31112501)
  carries 8.4 % where 100-1-GS/26 of 09.04.2026 reads 7.6 %. The item now asks the general
  question: when a reissue carries a determination forward, does *forward* mean the initial
  result or the latest on file?

**A stability timepoint never supersedes anything.** It measures the lot ageing; it is not
release or retest testing and no certificate of quality prints it. All three checks skip
the rows the register marks. Without that, the 05.03.2026 and 11.05.2026 stability pulls on
the two Grape Pie lots alone raise 30 findings that are not findings — CBN rising from
0.02 % to 2.35 % is a stability study reporting what it exists to report.

## Two register blocks carry two sublots — OI-39

The second check looks for a block holding two certificates of the **same testing** on the
**same day** that report **different results**. Over 93 blocks there are two, and the
documents themselves say what they are.

**J31122501** (Jokerz 31, P060262) holds three such pairs. The microbiology of 07.04.2026:
`231/0394/26` names its sample *Рачно тримиран цвет* — hand-trimmed flower — and reads TAMC
850, while `230/0393/26` names *Тримиран цвет* and reads 1900. The Farmahem cannabinoids of
09.04.2026: `100-2-К/26` at 19.84 % against `100-3-К/26` at 21.84 %. The IJZ mycotoxins and
metals of 23.04.2026: `1628/2026` against `1625/2026`. **JD112501** (Jelly Donutz, P060212)
holds one: `ППК26063` at 19.64 % total THC against `ППК26065` at 13.93 % — six percentage
points apart, which is not one sample read twice.

The owner's batch list gives each cultivation batch exactly one P lot, so the register has
no second number to file the second sublot under. `testing_series.rounds()` treats two
documents of one day as one testing period — which is right when they describe one sample —
so both sit in the release round and the certificate prints the first. The tracker shows
**both** as separate testing instances, so nothing is hidden anywhere the desk shows its
working. What the certificate of quality does not say is which sublot it certifies. That is
OI-39.

## Results on file that no certificate of quality prints

The third check is the mirror of the first: 128 results, over 20 lots. 70 are the campaign
microbiology of OI-38; 32 are in-house documents with no document number; **26 are ordinary
laboratory certificates on five lots** — `ППК25174` (P050022), `1155/2056/25` (P050202),
`100-1-K/26` and `100-1-GS/26` (J31112501), `230/0393/26`, `100-3-К/26`, `100-3-ГС/26` and
`1625/2026` (J31122501), `ППК26065` (JD112501). Each is either an intermediate retest round
that no certificate rests on, or the second sublot of OI-39. The count is a consequence of
the two open items, not a third finding; it is on the tab so the owner can see the whole of
what a ruling would move.

| | v34 | v35 |
| --- | ---: | ---: |
| determinations swept for supersession | 5 (microbiology) | **17** |
| total aflatoxins over 30 comparable lots | not asked | **0 contradictions** |
| lots carrying a second heavy-metal certificate | not asked | **0 — #11 cannot be swept** |
| contradictions settled by the ruling of 10.09.2026 | — | **8** |
| contradictions open on OI-38 | 26 rows, 12 certificates | **31 rows, 14 certificates** |
| register blocks carrying two sublots | not asked | **2** (OI-39) |
| open items | 38 | **39** |
| `verify_workbook` / `verify_prose` findings | 0 / 0 | **0 / 0** |
| truth check findings | 21 | **21** (the same items) |

## Reproducing

    python3 deliverables/qc_gap_analysis/result_supersession.py
    python3 deliverables/qc_gap_analysis/result_supersession.py --dets 10,11 --check superseded
    python3 deliverables/qc_gap_analysis/result_supersession.py \
        --md tracker/RESULT_SUPERSESSION_2026-09-16.md
    python3 deliverables/qc_gap_analysis/tracker/build_tracker_v8.py \
        --v9 --version=35 --icoa --cells --mikro=CoQ_Analysis_Master_v13.xlsx \
        --build-date=15.09.2026 --legacy-icoa=03.06.2026 --legacy-coq=06.06.2026 --t3-issue=21.09.2026

## The parallel desk's audit, answered

The Head of QC passed on `HANDOVER_to_ClaudeCode.md`: an audit of the 127 rendered
certificates in `Final_Docs/xCOAs/CoX_DES/`, built from v27/v29 and asking this desk to
confirm or refute seven findings. The point-by-point answer is
`tracker/HANDOVER_RESPONSE_2026-09-16.md`. In summary:

| finding | verdict |
| --- | --- |
| 2.1 · 41 documents have no in-house QC row | **confirmed** as a document defect, **refuted** as a builder defect — 82 certificates over 44 lots, and all 172 cite an internal certificate (OI-41) |
| 2.2 · certificate codes carrying analysis tags | **confirmed**, and the page settles the spelling — `ГС`, not `GS` or `LoD` |
| 2.3 · two attribution mismatches | **refuted** — 0 of 172 external rows credited with no result |
| 2.4 · one grade-token mismatch | **refuted** — 0 of 172 |
| 2.5 · four banner potencies out of window | **refuted** — 120 compared, 0 outside |
| 2.6 · loss on drying 76.07 % | **confirmed** — already OUT OF SPECIFICATION (OI-06, OI-35) |
| 2.7 · three document-code conflicts | **refuted** — no code sits on two lots |

**The one repair it produced: `document_codes.py`.** Farmahem numbers a report
`<campaign>-<item>-<analysis>/<year>` and the analysis letter is Macedonian — `К` for
канабиноиди, `М` for микотоксини, **`ГС` for губитоци при сушење**. Two pages were read on
16.09.2026 and both settle it:

    020326_051-1-LoD-26_FHM_J31102501-P060152.pdf → Извештај број: 051-1-ГС/26
    110226_031-2-LoD-26_FHM_PUM102501-P060112.pdf → Извештај број: 031-2-ГС/26

both titled «Извештај од анализа на **губитоци при сушење** во цвет од канабис». So `GS` is
a Latin transliteration and `LoD` an English abbreviation, and the owner's standing rule —
Cyrillic `К`/`М` in laboratory codes are genuine, do not transliterate — covers `ГС` too.
Both spellings reached the desk honestly: the scans' own file names carry `LoD`, an earlier
Farmahem extraction carries `GS`, and the register already spelled `100-2-ГС/26` correctly,
which is what made the inconsistency visible. `document_codes.py` does for codes what
`result_vocabulary.py` does for results — one spelling, applied on the way out of the
exporter — and it also takes a reader's OCR note out of the code field, so no certificate
prints `2156/2025 (microbiology sub-report lab-ref not distinctly captured in OCR text)` as
a document code.

It deliberately does **not** touch the six composites of the form
`PP CoA #027 / ППК25370`. Reading the register turned that from a spelling question into a
records one: each of the six also exists as a bare `ППК` row on the same lot, with an
earlier date and no results, so the results sit on the composite row and the row naming the
external certificate alone is empty. Which row is the certificate is the owner's — OI-40.

**Why 2.5 is worth reading twice.** The audit's four out-of-window banners are not random
numbers: 19.14 % is P060152's result, 11.53 % is P060182's and 19.64 % is P060212's — each
document carries the *previous* lot's assay, while its window is v35's own. The grades are
right and the assay values are one row out. It is the row-alignment trap the handover's own
§1 warns about, and it is on the document side, not in the master.
