# Purely Plant — QC package, 2026-09-10

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 78.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 77.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 17.0 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_CoQ_Drafts.pdf` | 18.7 MiB | Tranche 1 — 13 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_2_CoQ_Drafts.pdf` | 12.9 MiB | Tranche 2 — 9 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 864.0 KiB | All 22 certificates as one scrollable page |
| `workbook/CoQ_Analysis_Master_v21.xlsx` | 242.1 KiB | The desk workbook — coverage, registers, Reconciliation 09.09 |
| `workbook/coq_master_v21.html` | 688.3 KiB | The same workbook as a page, nine views |
| `desk/qc_quality_desk_artifact.html` | 3.0 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 12.1 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/icoa_register_2026-09-10.csv` | 10.5 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 18.2 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 18.3 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 6.9 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 27.6 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
661f8463f58601913d044a73d343f0a827a25188e4179469d8115c27b794649d  certificates/individual/DRAFT_CoQ_P050022.html
ca9b4dcddb7dd9b519bf278ac09c2ee2e65d4f0c91bf0374fbf5f73ea3a67fe3  certificates/individual/DRAFT_CoQ_P050052.html
e00f9dd051b93df0ef99105c859e53875c29ca46439ff9978456c162be92cab7  certificates/individual/DRAFT_CoQ_P050062.html
8c8423486f418bd614f725c4bcb5fa1898d6da4313dced053870935331565982  certificates/individual/DRAFT_CoQ_P050092.html
29c883b8c5587c626187c0c7f2e989df9855b15d5a4bfa959219b0f1b762092e  certificates/individual/DRAFT_CoQ_P050112.html
7055186af9fdb8ab11aeebaa3ff7707865e853fe4fdf0663c47922e0074efb6c  certificates/individual/DRAFT_CoQ_P050152.html
ad403493d5122ef0d3047e63d2394d072572fb26047c343e558870bb767a6c00  certificates/individual/DRAFT_CoQ_P050162.html
c893cc5623bef4a6952564bfddd63bdc22b8a3da0118d64a8507f8289cdb9868  certificates/individual/DRAFT_CoQ_P050182.html
5b92de1ef5407fa1d34213f64f610f15ec6553616cc40e892f14f29f2a726cbb  certificates/individual/DRAFT_CoQ_P050282.html
e33b46e58d5a1fe48764c66979fe2d1cfb3b7156091c07a284fd267201b95218  certificates/individual/DRAFT_CoQ_P050302.html
4aa739cd5a3bf63533aa26dd3997004f4d1bad32b146166cfb92bc0a39fbd22c  certificates/individual/DRAFT_CoQ_P050322.html
65102b4dbe63654f4bb5ea4b358f56f8f3c9d7fabc15c81a278ba5d80f809162  certificates/individual/DRAFT_CoQ_P060012.html
7daca082cbae39077e966da059163143a28542118376569f661a6a87e9e63f81  certificates/individual/DRAFT_CoQ_P060032.html
f792d19d0d55b7e2da9effb7cf15bea18bb215a835b89e12ddc2e0aaa390bef3  certificates/individual/DRAFT_CoQ_P060042.html
6bbdfae3a10bcfd48057cf8f2d5bf90d94c86031f8632cc1ba4daaddf9f0a4c3  certificates/individual/DRAFT_CoQ_P060062.html
ac70511a10f0b0d38fa26494cdb44577ed1573b995502b25b21807e85f56ace4  certificates/individual/DRAFT_CoQ_P060082.html
a2e192eb87a4a44da537c76de4734e99f23d8da99825c14b098ee25416969a99  certificates/individual/DRAFT_CoQ_P060092.html
4633e0b3625a6f06aecc89902723ffb3a25391006645bd2040f78ef5a6a61319  certificates/individual/DRAFT_CoQ_P060152.html
c1ebab94542897abde074a5f5ac75db47f8332f095c0f6809b196eee56905edb  certificates/individual/DRAFT_CoQ_P060172.html
c30ceb980c79932e5de4e68fd4cba0829e25b013a036a08bb73a92c664d3bfe5  certificates/individual/DRAFT_CoQ_P060212.html
ec7ce70cd0817d4113ea1fa8cb17beba82fea557222c640121d69e6ecb9f25cb  certificates/individual/DRAFT_CoQ_P060242.html
6dd2afc235e8ac26cf46fa6027f794fae702e40856af539ef152ad471aac4304  certificates/individual/DRAFT_CoQ_P060402.html
864d8f44a6d81a5de98a5caf31f41acfaf0072db2f101d72bb5843931020de65  INDEX.html
6bde0508e1f1424ab4e2e0e0edc9d02d7ea10d552df8e1c6df8dbc57d41605e2  certificates/Tranche_1_CoQ_Drafts.pdf
e781e2ddacdbbd2e8bf9f4335c6a57caa36c2c3b44cb39bdf32f18645ae925f5  certificates/Tranche_2_CoQ_Drafts.pdf
8cc1dc9dc5a60f8bc4aea20d9373b74b3a30d439d3662f986acd89db1a3dc998  certificates/Tranche_1_2_CoQ_Draft_Set.html
80cd8fa41a086523211ab6643e46346d2c27b78ed68a7af1e90388e0256acf4e  workbook/CoQ_Analysis_Master_v21.xlsx
3661446d160a57f44fb357deaeae5d5af04bbfb04ca855221f7b084871d02ab9  workbook/coq_master_v21.html
549b50d466c483cfe59465d79ec07974b9ea0a078d8bf47e0754fefdc3715fc8  desk/qc_quality_desk_artifact.html
58193df6d8e3fd4e3b3d09b83b612cdd2108b28b3c90a0dd1cb0130e497c36dd  sources/issuance_schedule_2026-09-10.csv
73187275ca92331e2db22c530a73ebeaf9f3e672f9ae31b3354ce222ad12838d  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
4a0b505e56165d717f90e459838a8c4743ec06a6fb09e512477fda98f4ff863e  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
ef5ebe8c29d0d636399383fe14da22a0314769dcc6d4dfb2f6206e5beb07ba2b  sources/coq_draft_gaps.csv
c2ae12cfd91c360dcfe1329493ffc37168ce2571724294f0c25be3bcf3d370fd  docs/ISSUANCE_RULES_2026-09-10.md
e14e9e051d6c568aaef66239190acd520ff2058f00f28c844993eaae623bfd1a  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
