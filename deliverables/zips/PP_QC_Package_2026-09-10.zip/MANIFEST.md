# Purely Plant — QC package, 2026-09-10

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 77.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 77.9 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 77.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 77.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 77.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 77.7 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 77.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 77.5 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/Tranche_1_CoQ_Drafts.pdf` | 18.6 MiB | Tranche 1 — 13 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_2_CoQ_Drafts.pdf` | 12.9 MiB | Tranche 2 — 9 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 853.8 KiB | All 22 certificates as one scrollable page |
| `workbook/CoQ_Analysis_Master_v21.xlsx` | 242.1 KiB | The desk workbook — coverage, registers, Reconciliation 09.09 |
| `workbook/coq_master_v21.html` | 688.3 KiB | The same workbook as a page, nine views |
| `desk/qc_quality_desk_artifact.html` | 3.0 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 12.1 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 18.2 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 27.5 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 6.9 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 27.6 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
0e5d19ce8b3b34430592deed0540adb9a30b97dd5664dfa5a7f8029a0c871650  certificates/individual/DRAFT_CoQ_P050022.html
e5c81c9c1b332a0f7ccbb995ea7916cd9762b7e0798403e52b0bf192aee927dc  certificates/individual/DRAFT_CoQ_P050052.html
c2082af8f57143b6dfbf5689fc2fd0b0975256e189546dd296e7c1f7e9afa6c2  certificates/individual/DRAFT_CoQ_P050062.html
fb2b2b292dd947d5490a3b8bdaf430fb7abf239974c27343aba94d581731c4b8  certificates/individual/DRAFT_CoQ_P050092.html
44833566cccda403f77a396c80d7b24d204f9b57d77fc1ea3850cfcc0a698764  certificates/individual/DRAFT_CoQ_P050112.html
345503caea1941eca0dfd79e7a805ab3aee273d4826bd09a45ad4ae66c5a420e  certificates/individual/DRAFT_CoQ_P050152.html
04cd2d428bf810b1805b1a84e99866396cdc04985f7f74848d6dbb55057ec080  certificates/individual/DRAFT_CoQ_P050162.html
b238953867c753ed07cfe51464deb81827b38d64c265b71ec6efebc736a72bfb  certificates/individual/DRAFT_CoQ_P050182.html
7e89bc8caece85f5a0db19592a658fd15136aa4cac01b57bb8aef753462ae9ce  certificates/individual/DRAFT_CoQ_P050282.html
745aa548400a1ec326c86114492f6b5cd361721f87cb5b04f182039618387d86  certificates/individual/DRAFT_CoQ_P050302.html
a871f012e2a25969812d2246261f051bb9c35d8304429feea410b12a3c9430d5  certificates/individual/DRAFT_CoQ_P050322.html
dbf0b072039f635899016b6564b4da7bbb8f066eb50ec2333dfa09b7af130a4f  certificates/individual/DRAFT_CoQ_P060012.html
78885aaf903fdbbc606afb5e2700dbc816de2e40c987e485a7428ad480408bff  certificates/individual/DRAFT_CoQ_P060032.html
5a1c204c9f31811013ebc736f3f2f6c4a944bf0ddf46d70a99720278abe9c14a  certificates/individual/DRAFT_CoQ_P060042.html
1b34c33f07c65cfdbbcf07df95a4efcd7d6744d39542f900d971c620353d742c  certificates/individual/DRAFT_CoQ_P060062.html
ddb648e4a15ee1c81305de857956f43b6436dd8dfab3dd16d29eb26e7d6973ba  certificates/individual/DRAFT_CoQ_P060082.html
aeaf945f76cc8e96f2afcfd7be27386f22319692324b3170f12e068621a3e282  certificates/individual/DRAFT_CoQ_P060092.html
e8eb31d46f8bb25eb9d019e4b143d8c9a0cafda524293a8a93ffdb731946c594  certificates/individual/DRAFT_CoQ_P060152.html
3380122aa99693e0c3d077831f7d67c2d2b398fb9d231d8246bdfe35a761058a  certificates/individual/DRAFT_CoQ_P060172.html
8412685e7565325e9f7aa049d39f84fc4e37b39e432530ccba7cf6aa7135259b  certificates/individual/DRAFT_CoQ_P060212.html
c0249b6f369b34ea91e8f926428ca6665efa4e2506ac5b3531dbeb4ecd94575c  certificates/individual/DRAFT_CoQ_P060242.html
5fc1e9c0ad2e3fd53a1aa6c9590325a4d245f8efb50ff64f3503716e981ae1d7  certificates/individual/DRAFT_CoQ_P060402.html
15616b4b68d29a1f0a5a43201d988648769d3f1ad9862b5a7cfdddf853b7d227  certificates/Tranche_1_CoQ_Drafts.pdf
c8f3264e4948feb743674adafed2d7749ff1db8718358ca8ddcbdc91baa19ff4  certificates/Tranche_2_CoQ_Drafts.pdf
7af687d38f18cd02766c8032200438c7b0182242f8b9db4519ebc6adbcac54d7  certificates/Tranche_1_2_CoQ_Draft_Set.html
80cd8fa41a086523211ab6643e46346d2c27b78ed68a7af1e90388e0256acf4e  workbook/CoQ_Analysis_Master_v21.xlsx
3661446d160a57f44fb357deaeae5d5af04bbfb04ca855221f7b084871d02ab9  workbook/coq_master_v21.html
f0560e146e4d71cd29acdb02ca18f24c9c4f566cf2557c91a511fe4fbf225917  desk/qc_quality_desk_artifact.html
58193df6d8e3fd4e3b3d09b83b612cdd2108b28b3c90a0dd1cb0130e497c36dd  sources/issuance_schedule_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
4a0b505e56165d717f90e459838a8c4743ec06a6fb09e512477fda98f4ff863e  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
9ac1bf700acc4187d207823c9a81bc151cdb152253bc731e564037841ce73752  sources/coq_draft_gaps.csv
c2ae12cfd91c360dcfe1329493ffc37168ce2571724294f0c25be3bcf3d370fd  docs/ISSUANCE_RULES_2026-09-10.md
e14e9e051d6c568aaef66239190acd520ff2058f00f28c844993eaae623bfd1a  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
