# Purely Plant — QC package, 2026-09-10

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 78.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 77.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 17.0 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_CoQ_Drafts.pdf` | 18.8 MiB | Tranche 1 — 13 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_2_CoQ_Drafts.pdf` | 13.0 MiB | Tranche 2 — 9 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 863.8 KiB | All 22 certificates as one scrollable page |
| `workbook/CoQ_Analysis_Master_v21.xlsx` | 242.1 KiB | The desk workbook — coverage, registers, Reconciliation 09.09 |
| `workbook/coq_master_v21.html` | 688.3 KiB | The same workbook as a page, nine views |
| `desk/qc_quality_desk_artifact.html` | 3.0 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 12.1 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/batch_dates_2026-09-10.csv` | 5.4 KiB | Harvest and packaging windows per batch — where the internal CoA's testing dates come from |
| `sources/icoa_register_2026-09-10.csv` | 10.6 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 18.2 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 18.3 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 12.1 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 31.5 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
49f68fabb0fee2579650bc475609b698f9d988725c3cd332ff8c11754bbe836f  certificates/individual/DRAFT_CoQ_P050022.html
3ecbc3ac21f2c7f9d1feb93e62e82e1edea1349e88f7e67cc7e737e0c1577723  certificates/individual/DRAFT_CoQ_P050052.html
e6d847c52df0c9b727834f803061d93900ab0f964e9b8e227c43b42e9bba1357  certificates/individual/DRAFT_CoQ_P050062.html
36b3bbc16f0887f9651b81e8510efe4ce99be0d821b7fe9330f698d24693881d  certificates/individual/DRAFT_CoQ_P050092.html
d7b45e09818da5f7ae12a25bf120c8ae27ca39dfa45e72c19373aac51b9c5bc9  certificates/individual/DRAFT_CoQ_P050112.html
1b4c8fc24aa90e3e54f72eeb487599fad5018b6074528a6eeae4b0ccae63df51  certificates/individual/DRAFT_CoQ_P050152.html
bf78199af489498627c3b860935014453c4ec66c75d9beb63e011f719dbf36f8  certificates/individual/DRAFT_CoQ_P050162.html
5ac3f9f4585952a316b75a95b7691cc6ff6e87cc52953603c70e7ea534620433  certificates/individual/DRAFT_CoQ_P050182.html
a25f57852cc87fcaf1c95230bffdc277a28292cc445ed0526545a3d111c1e44a  certificates/individual/DRAFT_CoQ_P050282.html
e94eed7f2c06a97f1f499b1516b94066258bbeb26c6f1355a5d5724eefd5344f  certificates/individual/DRAFT_CoQ_P050302.html
6c5ab3d0c65511d6c69bf8a623b1f8efd37f21cb98da6bcf5770302ab391b788  certificates/individual/DRAFT_CoQ_P050322.html
f181d2c8617e01d4e320c2e247b9b7e9f4215a54d13a76e5bff43563148adfe3  certificates/individual/DRAFT_CoQ_P060012.html
b318d20db0c1eec2b737c2e87f83de0f973387fa3b69948e933bf88cbaa9bf89  certificates/individual/DRAFT_CoQ_P060032.html
408fedfb1cfdd29d1e4aebf498db3dd46b0168be64ecb485e744ef7f17af3a11  certificates/individual/DRAFT_CoQ_P060042.html
988718ccbc43dca14a8b423600cc05c9a34306e58f0e0159c36cc97175359ab5  certificates/individual/DRAFT_CoQ_P060062.html
bf04e836d43f5953b6de19b6f3697ca262e8929405e04ba4fb0e4c319f0217be  certificates/individual/DRAFT_CoQ_P060082.html
4cd743e9369d07858e5cc88558ef7e6890554837fed1c70368e7be6e2f81ad62  certificates/individual/DRAFT_CoQ_P060092.html
5a54952cb2bdf23ccefb7b4700d0b97d7179e8da0671af52ea9733d9416a0539  certificates/individual/DRAFT_CoQ_P060152.html
ab7b5edcc3de75b9219ed5a259ddc3db0b3d59a999443aa4aa9bdead0a7c01c7  certificates/individual/DRAFT_CoQ_P060172.html
25c846b93786c64b39191d1456a48ead77bf3ca66b2b2cf005a2f284f7be162e  certificates/individual/DRAFT_CoQ_P060212.html
d4a0f0ff6af3f274a035dd4616586d0e214f37939c8f7ab89cc0539aa2bb1314  certificates/individual/DRAFT_CoQ_P060242.html
6dd2afc235e8ac26cf46fa6027f794fae702e40856af539ef152ad471aac4304  certificates/individual/DRAFT_CoQ_P060402.html
864d8f44a6d81a5de98a5caf31f41acfaf0072db2f101d72bb5843931020de65  INDEX.html
0ffc0d9f557f2773b6f4bb5a5bc03f5c1c983ffd544fffe8a53d3daf5d7fe1b2  certificates/Tranche_1_CoQ_Drafts.pdf
1f86611cd3ffdfb07a86561d884c549aa8e2a2497f36b9be1663d37781205289  certificates/Tranche_2_CoQ_Drafts.pdf
9c4152b6cf15a226e0853c301b506d30d7b4f01275016b3682b321d0b683f17a  certificates/Tranche_1_2_CoQ_Draft_Set.html
80cd8fa41a086523211ab6643e46346d2c27b78ed68a7af1e90388e0256acf4e  workbook/CoQ_Analysis_Master_v21.xlsx
3661446d160a57f44fb357deaeae5d5af04bbfb04ca855221f7b084871d02ab9  workbook/coq_master_v21.html
69ecc14fd59d115f5e026a111b808b0ba1a89ac878e634ba34bd3a02c929f439  desk/qc_quality_desk_artifact.html
58193df6d8e3fd4e3b3d09b83b612cdd2108b28b3c90a0dd1cb0130e497c36dd  sources/issuance_schedule_2026-09-10.csv
22f2e9cc57bdbc1fab4a8ee8cc3146d34ee647515a5e294a9781526f79f047f9  sources/batch_dates_2026-09-10.csv
55a883482b08c5a4cf7f7ebd5ce16f5a002ba54854c0dc483f2052a83950c4fe  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
4a0b505e56165d717f90e459838a8c4743ec06a6fb09e512477fda98f4ff863e  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
ef5ebe8c29d0d636399383fe14da22a0314769dcc6d4dfb2f6206e5beb07ba2b  sources/coq_draft_gaps.csv
f71293be9891e0f81d360b11999b5dd95a45c89636d2a18e58340b923d66c9d6  docs/ISSUANCE_RULES_2026-09-10.md
101232cbe02dabe959f4ac14e3f9bdd773bfa6ff42bf2172d41b88389a7f157f  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
