# Purely Plant — QC package, 2026-09-10

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 78.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 77.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 17.0 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_CoQ_Drafts.pdf` | 18.8 MiB | Tranche 1 — 13 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_2_CoQ_Drafts.pdf` | 13.0 MiB | Tranche 2 — 9 certificates, one A4 page each, fonts embedded |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 863.8 KiB | All 22 certificates as one scrollable page |
| `workbook/CoQ_Analysis_Master_v21.xlsx` | 242.1 KiB | The desk workbook — coverage, registers, Reconciliation 09.09 |
| `workbook/coq_master_v21.html` | 688.3 KiB | The same workbook as a page, nine views |
| `desk/qc_quality_desk_artifact.html` | 3.0 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 12.1 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/icoa_register_2026-09-10.csv` | 10.5 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 18.2 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 18.3 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 10.1 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 29.8 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
0faeaae84510468d617d8933a1b047c0974a7582b9ba6767af95b408fa607171  certificates/individual/DRAFT_CoQ_P050022.html
a95f436319ab9b9a78319dd9a37a522b7310449b293932b3e3df5698cc72621a  certificates/individual/DRAFT_CoQ_P050052.html
c1e38efec22a804df74590264333ad392f3a7cf7df39e9cbbdd4ee013739dda0  certificates/individual/DRAFT_CoQ_P050062.html
2585bbafcb61ea79d6ad4b2a40ffb5ca208d452ff7d77befc2e6977179610124  certificates/individual/DRAFT_CoQ_P050092.html
f701efef98cb1e912630df3e384d9f9bf42a6be5f9d20d760e642dc17e1d5111  certificates/individual/DRAFT_CoQ_P050112.html
20aef80cedacf144bb905f549d663db3aa0ef8f8e656c8e5204b74eaefc9e6a7  certificates/individual/DRAFT_CoQ_P050152.html
a759ca0b6b9a09e8c5106ba3f686fc6d0e629f2088cadda2de26211b6b3d7765  certificates/individual/DRAFT_CoQ_P050162.html
0327c20a7715d1deedfd039a550c0dbc8b0539d6474469d8cd694e1a85db5fef  certificates/individual/DRAFT_CoQ_P050182.html
fa86360dcbb036671c60e4e19a539bb1e96729d1e0a05b8ec8fbc81099bce551  certificates/individual/DRAFT_CoQ_P050282.html
e94eed7f2c06a97f1f499b1516b94066258bbeb26c6f1355a5d5724eefd5344f  certificates/individual/DRAFT_CoQ_P050302.html
518fac3d5aea997b3be42d4db1d42d3ae86b5b34cc0204f8590bcc952496e46a  certificates/individual/DRAFT_CoQ_P050322.html
af8e196151554f9aa2d4585974c33416b0bcee3382fd652182c17388c44847d5  certificates/individual/DRAFT_CoQ_P060012.html
1dc664b29adb0dd66ee92c672dcd92259312d65f6f49b1232a3447e71adda231  certificates/individual/DRAFT_CoQ_P060032.html
003c7e87d1a85abf8041f7cdfe42748a21c5ce77253820affd5d6a6c366911a4  certificates/individual/DRAFT_CoQ_P060042.html
c04a2f108912458a2ec3e73c81abeb56098d1f528b6a001b86d55de87c4d3c37  certificates/individual/DRAFT_CoQ_P060062.html
46e2f01c0da40c82681a92d3cfc77d5eb0848eaf6d70d090e4f62f5867bc3006  certificates/individual/DRAFT_CoQ_P060082.html
c346b73bb8e9eeeeb44efa8118a03473cc13a03b95214f34db821692d0af531e  certificates/individual/DRAFT_CoQ_P060092.html
5a6875252a73341c4d4af46197ea526e9a33550492989cf775d457d2752c4484  certificates/individual/DRAFT_CoQ_P060152.html
d23d770c4bbd3d115684bb0a8ec420f8d3a58f459e5c53e488b2420aa014feca  certificates/individual/DRAFT_CoQ_P060172.html
795b884a95f2a3686a866f23608c89e87e6fb1e5698572ff152bd9a6d9f6cb13  certificates/individual/DRAFT_CoQ_P060212.html
2b97a74a1a6b5d7e5d8d6c25eb71ee391144619080366a642f8213bb1ab1b011  certificates/individual/DRAFT_CoQ_P060242.html
6dd2afc235e8ac26cf46fa6027f794fae702e40856af539ef152ad471aac4304  certificates/individual/DRAFT_CoQ_P060402.html
864d8f44a6d81a5de98a5caf31f41acfaf0072db2f101d72bb5843931020de65  INDEX.html
0c6ff2ab0da582ea23df2d7e848d71606d84ab06fe45220a2004503eb9c33c4c  certificates/Tranche_1_CoQ_Drafts.pdf
a88f0b57ad8569c49aa4555208ff6d2dc7d56670711bc72a4a8d2eab9450acde  certificates/Tranche_2_CoQ_Drafts.pdf
c93f997a1c52ada5c0d05abfa895dd739140f5555a62f1caa76e6c65b8a86169  certificates/Tranche_1_2_CoQ_Draft_Set.html
80cd8fa41a086523211ab6643e46346d2c27b78ed68a7af1e90388e0256acf4e  workbook/CoQ_Analysis_Master_v21.xlsx
3661446d160a57f44fb357deaeae5d5af04bbfb04ca855221f7b084871d02ab9  workbook/coq_master_v21.html
16b0931838b28555588b781efd136879cbe80634f1420be18ec41b0b858a2370  desk/qc_quality_desk_artifact.html
58193df6d8e3fd4e3b3d09b83b612cdd2108b28b3c90a0dd1cb0130e497c36dd  sources/issuance_schedule_2026-09-10.csv
73187275ca92331e2db22c530a73ebeaf9f3e672f9ae31b3354ce222ad12838d  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
4a0b505e56165d717f90e459838a8c4743ec06a6fb09e512477fda98f4ff863e  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
ef5ebe8c29d0d636399383fe14da22a0314769dcc6d4dfb2f6206e5beb07ba2b  sources/coq_draft_gaps.csv
1a52e1ec7f4567a66c70a318c1482c457b6f804ce552a9a6f5e2ffab42615315  docs/ISSUANCE_RULES_2026-09-10.md
4ff35759af0c0245d7015bfeb1a1e72192a24e3271f8bbcb96eb32fd6f8f5e7e  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
