# Purely Plant — QC package, 2026-09-16 — workbook v40 (no PDFs)

Everything the QC desk has produced, as it stands. Every certificate in
here is a **DRAFT**: watermarked, unsigned, its conformity statement
unticked, and every field the desk cannot stand behind bracketed in red.
**None has been issued.**

The four compiled tranche PDFs are **not** in this archive — they come to
104 MiB together. Every certificate is still here as HTML, individually
under `certificates/individual/` and as two scrollable sets. The PDFs
download on their own from `deliverables/qc_gap_analysis/drafts/` in the
repository.

| file | size | what it is |
| --- | ---: | --- |
| `certificates/individual/DRAFT_CoQ_BG1024_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_BSS1024_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_GG1024_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_HPA1024_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_OPM1024_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050022.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050022_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050042_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050052_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050062_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050072_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050082_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050092_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050112_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050152_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050162_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050182_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050192_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050212_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050222_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050282_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050302_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050312_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322.html` | 78.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P050322_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060012_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060022_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060032_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060042_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060062_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060072_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082.html` | 78.1 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060082_reissue.html` | 79.3 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060092_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060112_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060122_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060132_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060152_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060172_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060182_reissue.html` | 78.6 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060212_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060232_reissue.html` | 79.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060242_reissue.html` | 79.0 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060282_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060322_reissue.html` | 79.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060332_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060352_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060362_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060372_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060382_reissue.html` | 78.4 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060402_reissue.html` | 78.7 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060412_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060422_reissue.html` | 78.8 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `certificates/individual/DRAFT_CoQ_P060492_reissue.html` | 78.2 KiB | Certificate of quality, one lot — DRAFT, unsigned |
| `INDEX.html` | 18.1 KiB | Start here — every sheet, what the archive holds, what to read first |
| `certificates/Tranche_1_2_CoQ_Draft_Set.html` | 853.7 KiB | All 22 release certificates as one scrollable page |
| `certificates/Tranche_1_2_CoQ_Reissue_Draft_Set.html` | 1.9 MiB | Every reissue as one scrollable page |
| `compilation/CoQ_compilation_v40.xlsx` | 421.5 KiB | The owner's first request: one row per certificate of quality, and for every determination #1 to #12 the result, the document, its date of issue and its laboratory |
| `compilation/CoQ_compilation_v40_wide.csv` | 321.3 KiB | The same table, one row per certificate |
| `compilation/CoQ_compilation_v40_long.csv` | 1.1 MiB | The same table, one row per certificate AND determination, with the method, the acceptance criterion, the sample receipt date, the status and the route |
| `references/CoQ_references_v40.xlsx` | 34.9 KiB | One row per certificate, one column per determination — the document each rests on |
| `references/CoQ_references_v40.csv` | 80.0 KiB | The same, flat |
| `references/CoQ_references_v40.md` | 86.1 KiB | The same, readable |
| `references/CoQ_references_v40_nt.md` | 26.5 KiB | Every cell that reads 'not tested', for review |
| `workbook/CoQ_Analysis_Master_v40.xlsx` | 781.7 KiB | The desk workbook — coverage, registers with the 10-11.09 issue dates, Reconciliation 09.09 |
| `desk/qc_quality_desk_artifact.html` | 3.2 MiB | The live Quality Desk — click a batch to compile its certificate |
| `sources/issuance_schedule_2026-09-10.csv` | 21.7 KiB | Every certificate and internal CoA with its date, under the 10.09 rulings |
| `sources/batch_dates_2026-09-10.csv` | 5.4 KiB | Harvest and packaging windows per batch — where the internal CoA's testing dates come from |
| `sources/icoa_register_2026-09-10.csv` | 24.7 KiB | The standing internal-CoA register — 106 certificates, coded in issue order |
| `sources/spec_attributes_2026-09-10.csv` | 58.0 KiB | Phenotype, dominance, chemotype, processing and packaging, read off 257 issued specifications |
| `sources/coq_register_2026-09-10.csv` | 25.0 KiB | The workbook's own CoQ register, lifted |
| `sources/cell_resolution_2026-09-09.tsv` | 93.9 KiB | The owner's 09.09 pass — 600 determinations resolved to a document |
| `sources/coverage_update_2026-09-09.tsv` | 9.6 KiB | The 09.09 coverage update |
| `sources/identity_block_2026-09-09.tsv` | 4.7 KiB | The identity determinations, batch by batch |
| `sources/coq_draft_scope_2026-09-10.csv` | 5.1 KiB | Which of the 50 delivered batches are draftable, and why the rest are not |
| `sources/coq_draft_gaps.csv` | 8.0 KiB | Every blank printed line on the 22 certificates, with its cause |
| `docs/OPEN_ITEMS.md` | 63.3 KiB | Everything still the owner's to decide — what was found, what the desk did, what is being asked, and the evidence behind each |
| `docs/RESULT_SUPERSESSION_2026-09-16.md` | 15.0 KiB | Does any certificate print a result the record has replaced? The sweep over all seventeen determinations — READ THE COVERAGE TABLE FIRST: no lot on file carries a second heavy-metal certificate, so #11 could not be compared at all |
| `tables/Batch_Parameter_Sources_v40.xlsx` | 272.8 KiB | Asked for on 16.09.2026: one row per batch, one column per determination #1 to #12, and in the cell the document that certifies it with its date of issue — [internal] where the citation is the company's own certificate of analysis, and both the release and the reissue citation where they differ. Second sheet: the same one row per batch, certificate and determination |
| `tables/Batch_Parameter_Sources_v40.csv` | 144.8 KiB | The same table as text, one row per batch |
| `tables/Batch_Parameter_Sources_v40_long.csv` | 771.7 KiB | The same table, one row per batch, certificate and determination |
| `docs/COMMUNICATION_CoQ_RELEASE_2026-09-16.md` | 13.8 KiB | The internal announcement of the prepared set, to the executive and the department managers — Macedonian first, then the same text in English: what is issuable, how the potency ranges were set, what the internal certificates of analysis carry, and which certificates are still waiting on a laboratory document |
| `docs/FLEET_FINDINGS_2026-09-16.md` | 11.9 KiB | What twelve agents found reading the primary records on 16.09.2026, sorted into defect (fixed, or named as not fixed and why), question for the owner, and no action — including two claims that did not survive checking |
| `docs/HANDOVER_RESPONSE_2026-09-16.md` | 13.0 KiB | The parallel desk's audit of the 127 rendered certificates, answered finding by finding — four refuted with the comparison counted, three confirmed |
| `docs/TRUTH_CHECK_2026-09-15.md` | 8.5 KiB | Every parameter result and every cited document checked from the primary records forward, by a code path that imports none of the builders |
| `docs/VOCABULARY_2026-09-11.md` | 95.1 KiB | The 11.09 audit of parameter values and references: one spelling per assertion, and the laboratory verdict the desk could not read |
| `docs/ISSUANCE_RULES_2026-09-10.md` | 18.8 KiB | The 10.09 rulings, what they changed, and what is still to build |
| `docs/COQ_DRAFTING_2026-09-10.md` | 31.5 KiB | How the certificates were drafted, in five revisions |
| `docs/V20_RECONCILIATION_2026-09-10.md` | 10.2 KiB | The owner's v20 workbook reconciled into the desk |
| `docs/DELIVERY_RECONCILIATION_2026-09-07.md` | 13.8 KiB | Delivery against what is on file |
| `docs/drafts_README.md` | 9.5 KiB | What the certificates are, and what they still lack |

## Checksums

```
f7213d28945cf426c771e6014c32ddcf04f18edb16c4ab1c5dad05c809b04496  certificates/individual/DRAFT_CoQ_BG1024_reissue.html
c629fec31f154f36fd60c59379bd4502a7ae781bedf766426da8c288393cbcce  certificates/individual/DRAFT_CoQ_BSS1024_reissue.html
95da125b6c3c9b6af4940fb35fd8b8f9d95f5356e03eecfc71e7a84eb86219d2  certificates/individual/DRAFT_CoQ_GG1024_reissue.html
80a5a1e6eade67864dd71df871c2ec5bb7835b415eb68232b1daca8428318078  certificates/individual/DRAFT_CoQ_HPA1024_reissue.html
fafc2a84ab98f0605dbf3d79a9c719a3861557eb73cf29cf1370bc2d692e1e99  certificates/individual/DRAFT_CoQ_OPM1024_reissue.html
78b1ab3c1d17934ed12e7ff32fa39189de4530ce4dd77b7b485694e7c37f635b  certificates/individual/DRAFT_CoQ_P050022.html
b60542ac94ba81b55fac93e4d9a382265b72dc2e1736d50b809c8faf22a6ee89  certificates/individual/DRAFT_CoQ_P050022_reissue.html
edf3c77e8f12389c3b8729d666182fd6c4a0972841237169efbb6545327db1b2  certificates/individual/DRAFT_CoQ_P050042_reissue.html
ef2d522b3afb61058c9afeeb1383b798e3629872c19406e5929e0db3770e97db  certificates/individual/DRAFT_CoQ_P050052.html
0ab0948b7083b2ef53dacd83e276f559f7fdc09787d362055b27501129555ebd  certificates/individual/DRAFT_CoQ_P050052_reissue.html
f1dff42d68e130ae4e9b1b7273b0da72fb9ba12f78c616587e5009205785463c  certificates/individual/DRAFT_CoQ_P050062.html
7802ebcf72babfe018112727bf4d893afe2d50da77c2b2388cf775a242533b80  certificates/individual/DRAFT_CoQ_P050062_reissue.html
93f3618c5649948f02736db7e63472a9fcb7e088510a7d4ad7ca4f78b17c93c6  certificates/individual/DRAFT_CoQ_P050072_reissue.html
9e4ff182a697e22ce731f3312a785195547083dc25871671439d39796b94c01a  certificates/individual/DRAFT_CoQ_P050082_reissue.html
d50753c96d03f3ab4ff81af436f3288af1d3f0dcd448ce5e99bd197635641190  certificates/individual/DRAFT_CoQ_P050092.html
87111a8e3cfe7da131e4ee03ab2bea4f10b9ae24ee3a9308af9e42ec737f56f9  certificates/individual/DRAFT_CoQ_P050092_reissue.html
dbb94f7c4c0e96cc887c7c789d462443498b44421cf6736a24edd4d27a7f3cc4  certificates/individual/DRAFT_CoQ_P050112.html
a75e95d93810094d872dc0ced05783e5c01b31fa0140848cd95367e96b218947  certificates/individual/DRAFT_CoQ_P050112_reissue.html
15093106c9a3f27d435fb7d2c4845cafeb786e2a79e35ad5b5b12ec4fa2cb171  certificates/individual/DRAFT_CoQ_P050152.html
475a1dbc07ac1394a0a4e42a8d1dd7279e311d63f1b48b8dcadfb8d76151a6d1  certificates/individual/DRAFT_CoQ_P050152_reissue.html
de5245a53b00068ff55aed9b1f8c858d7da413ec93522eaf00449a02e7379e20  certificates/individual/DRAFT_CoQ_P050162.html
6d3dbfd0ff8d9eb55518a602acf280bbb22b89b625756b74ef4727c9b3a9e584  certificates/individual/DRAFT_CoQ_P050162_reissue.html
f00fcf664c87639cac0a6c110acf1265cfb52e24bbbd24b77d9b3b2a60ec56c5  certificates/individual/DRAFT_CoQ_P050182.html
a532590bad65835a1902a636bf0c51a736b98d2196026bc03fcc4a8812b762f7  certificates/individual/DRAFT_CoQ_P050182_reissue.html
70c10f18924fde5af62f2d644ca856049505180d8e0b0329ece608c4b3bcddba  certificates/individual/DRAFT_CoQ_P050192_reissue.html
e2ef33d349c6bdb2dfebfe0d54e9591fa7e8bf4a0a13401b40e402748df6b3f4  certificates/individual/DRAFT_CoQ_P050212_reissue.html
06b59ff1fc97734dc352d316268b915da2ad9f985951a221f32db2273ce2fc97  certificates/individual/DRAFT_CoQ_P050222_reissue.html
958a5fdb91a990ab06ae9cc8238a6bff9ed04ed95096ceba30e3375f09b83ed1  certificates/individual/DRAFT_CoQ_P050282.html
022a93e2385401d1ff617396ff2b0818a5f143ad56c447739d24aa7fe9b8a38f  certificates/individual/DRAFT_CoQ_P050282_reissue.html
b3912cd1c2d0ef3d37f61071563f0b43881260915efd6fcdc6ae33b2ea8ec871  certificates/individual/DRAFT_CoQ_P050302.html
bc2b44e69dede0d0b1cd43a4674829c16e26aa4f123c651e36e13c579b3efb17  certificates/individual/DRAFT_CoQ_P050302_reissue.html
7db54e13f514237ad0f03011eb71e4d3ca45fdd7105ddb8f4b57088fb911e6c0  certificates/individual/DRAFT_CoQ_P050312_reissue.html
2a3758b2120a1fe1269647bceb622bfe03c35e487bac1b3d466d31b364a04084  certificates/individual/DRAFT_CoQ_P050322.html
fb094f02274aad3d5250cdd934f412289b9a8055e973759d71c0ab7d1e76caac  certificates/individual/DRAFT_CoQ_P050322_reissue.html
a6ce47c3d410e57a031c477cdee2af1dbf967935606ac0aab583a2c48f6afe12  certificates/individual/DRAFT_CoQ_P060012.html
b1f3a6e3490c9df4aef3c23fbf14959d830d22a275ea5bb1cc902c834bc366bd  certificates/individual/DRAFT_CoQ_P060012_reissue.html
84483fc0f54e7c9cfeea101b9535928c79b21fc7f72da079db49d850ae9d95bf  certificates/individual/DRAFT_CoQ_P060022_reissue.html
9ba10f25f54a3e45b24a5ba43a06ea21fa2ee4c94f3c514c5bebf08535dda296  certificates/individual/DRAFT_CoQ_P060032.html
947196a87fcc8c5e1d1126f22a210e71e347437ebb6bc0eb9092c7b5c5846fb5  certificates/individual/DRAFT_CoQ_P060032_reissue.html
1e80b083d71c207b789b861d13858b4a0e0e82f8c496dcf8bb0e4e968152134e  certificates/individual/DRAFT_CoQ_P060042.html
4e7224cdb7b9865e0c1f3a8bcb9a87466550faedffc8545332ffd6a70e17ed61  certificates/individual/DRAFT_CoQ_P060042_reissue.html
3e78592ebe33890fc0582604e74b527e661fc71d5e95b77a8d4e18b4d157dcf3  certificates/individual/DRAFT_CoQ_P060062.html
7d7cc5ef42d08c48bf32de0d5c782c5945a4561b45f4b3f97516263ad9537355  certificates/individual/DRAFT_CoQ_P060062_reissue.html
cf77836eddb446077ef5764d59dce47e69b0f0e5f108011ac1c5a767b34e4ee6  certificates/individual/DRAFT_CoQ_P060072_reissue.html
136f55977e39d053e6a81df10955b5073d6f93b6c02e17e1639818174566eaa1  certificates/individual/DRAFT_CoQ_P060082.html
174f635574d85ead27e8839fc623ad2db84e25dc875790514e063ba80a7c5568  certificates/individual/DRAFT_CoQ_P060082_reissue.html
cffe09e04f965fb469680cf9470ba2629702b8679801e980cbe895cb03fdc04d  certificates/individual/DRAFT_CoQ_P060092.html
f9ee7da4090609da7213d9db08ffe60acfcc9f54fd49e50f2703472f6a56630c  certificates/individual/DRAFT_CoQ_P060092_reissue.html
b0364082cca1c96f36cbbfd2b606e22ef03b9ecc3baa958f78603aea36d2ccdc  certificates/individual/DRAFT_CoQ_P060112_reissue.html
b5ac3b6e72ec87390fc07c7478067c97d5316406e710e2d19ef53ea1d47e6c84  certificates/individual/DRAFT_CoQ_P060122_reissue.html
103f85a08bdf65f64065d13456933e1bd726c9a4a2d9c558f0cd0784898ad262  certificates/individual/DRAFT_CoQ_P060132_reissue.html
81598bc87bb4e028fd214f42318a52aed47bbef1979fcd1ae346fb3003047594  certificates/individual/DRAFT_CoQ_P060152.html
1b322458f244c91940c2042102830606602143a59765837564f9ba220d39ffcf  certificates/individual/DRAFT_CoQ_P060152_reissue.html
24188c51931c2cbb2c021b3099072dc026850260f44b0f36b24357cd235094a6  certificates/individual/DRAFT_CoQ_P060172.html
4a607bee4cbd1aee2b7b829706a1dff3e4d906d031b64948d9c3ac33d276dc6b  certificates/individual/DRAFT_CoQ_P060172_reissue.html
f4d30ec97ec2ca4ca483804fe9b1d87ad2b39fd05b1af95ca9f19ed751b4c604  certificates/individual/DRAFT_CoQ_P060182_reissue.html
c6fa9f8579651e23e28618abd7a72e5db975be189bbe0e6fc3a33d555206a3cf  certificates/individual/DRAFT_CoQ_P060212.html
d1d8eaeb797e3a80928f13b2b63dd2755583b0248646f41feee421de1719f0fe  certificates/individual/DRAFT_CoQ_P060212_reissue.html
c6dd5d03ab788d194a1f315dd35bfd4e9efc80cdb59add7c2eb61aec9ecfacc2  certificates/individual/DRAFT_CoQ_P060232_reissue.html
a1e0bba3762d3275ef58df1efe292b5741985bc477f50495b433a92b194851ae  certificates/individual/DRAFT_CoQ_P060242.html
95a6c7eb0fdac11a8c0b3a7c31fae4d589113d7cdaffc183e19e72613034aad3  certificates/individual/DRAFT_CoQ_P060242_reissue.html
3a41085077a42c67fceb3fb9127edaff0b1a10c445ba0db890bb7fa4c9933728  certificates/individual/DRAFT_CoQ_P060282_reissue.html
adf1479b900b491b98c1d6d589d31340b5a4d6a79464bd9c740983848e85e2de  certificates/individual/DRAFT_CoQ_P060322_reissue.html
da0c1c9d2c5874e2bf6864f15912dcc322c230f754b5412d2c5aad46f14c102a  certificates/individual/DRAFT_CoQ_P060332_reissue.html
486acad9701e540911f04a16bc77fa581d7816dda9d12312820c4994f9173f8d  certificates/individual/DRAFT_CoQ_P060352_reissue.html
e73d71818529e7577f60e5c913e361f5a558ddb55d4a8c3afae1aea1b2071fc6  certificates/individual/DRAFT_CoQ_P060362_reissue.html
79cf69a338fab55587bab77295b2d256cacf940b0479c1ae413557007dcc1d70  certificates/individual/DRAFT_CoQ_P060372_reissue.html
e73f3f5de01c96bda386fef8c9fec358f11f5e3b08b3c178831eeea55115736d  certificates/individual/DRAFT_CoQ_P060382_reissue.html
aa4e90379c64524c368a0acf0b16dca789e0daac4928e6b2cfdd282684f44dc7  certificates/individual/DRAFT_CoQ_P060402.html
bce27df6b624b622482421d5b0b1f74664e0bc34dc977b60fab22bab390eb449  certificates/individual/DRAFT_CoQ_P060402_reissue.html
79abe897c26103bf9e2d430d9a3eb899d50af5f09a85ff4adf29d995ab4b1b0e  certificates/individual/DRAFT_CoQ_P060412_reissue.html
7385eed89dbe6aff6d5691d099cd4e51ad20690cee9da1be0c675d52bdd84ac9  certificates/individual/DRAFT_CoQ_P060422_reissue.html
c2c6cfb6777d9e2c066d1bbb82602f7310d754b6419e2309c23fc658a220c932  certificates/individual/DRAFT_CoQ_P060492_reissue.html
e396d0e21fe89a186e879f11a0d8267940a6316b3a855903114856b3c47b002a  INDEX.html
6e074b837e6c4fe4e27ba1c1327c8840220ef8619b16e7a931814813ea75db7c  certificates/Tranche_1_2_CoQ_Draft_Set.html
87553480a86698a633dd3ac5ce316e43f66415e3e03c3595ae52247adcbc7204  certificates/Tranche_1_2_CoQ_Reissue_Draft_Set.html
8b333a8e5b045fb59bed09fd1b0893838cfddfb3a810428f6baf7bb13cba632c  compilation/CoQ_compilation_v40.xlsx
234801f1da711378bdd2ac01aa70223ae648c8efcbdd291d46addbb0336ca745  compilation/CoQ_compilation_v40_wide.csv
11d8f9043bd7e82cc18f9ce3ad199b9b386dc7b0de4eb68d5fa68cfca9877fee  compilation/CoQ_compilation_v40_long.csv
b52ab31f29af8d8ca3eb534f2d88ca7ae1d109a79f87798d1b8dee6762aa0d98  references/CoQ_references_v40.xlsx
5f62dfdfd8190d1e46266206f5d7dcb4a16dbc8cc00a561a4deecc7a6cf7ed59  references/CoQ_references_v40.csv
faa52fe6c9f1bdeb161f6a02672befb2cf348ecd8642e86ea00effb204238839  references/CoQ_references_v40.md
5e6d79406f3df5a95e8d7676ba3643659fd677ece6d1d4f497503b897fee177b  references/CoQ_references_v40_nt.md
0fdc11ac5cba59cb1b84ec5e6ed85033d11ef1fc3d3c4da4278280f41aba0b32  workbook/CoQ_Analysis_Master_v40.xlsx
2a3f9300683a3cb542f965e0dec2ca3c4399a49bf335de2bdcb871e734919288  desk/qc_quality_desk_artifact.html
1e41cc9d9970abf09b8ebde266bd7dd133fb837b6afd1eb0414fc22754ac5fa5  sources/issuance_schedule_2026-09-10.csv
22f2e9cc57bdbc1fab4a8ee8cc3146d34ee647515a5e294a9781526f79f047f9  sources/batch_dates_2026-09-10.csv
b7231261c4dfdbffa67f15140abc0b0da53f585b9f38cedb0adee3be60bb0c88  sources/icoa_register_2026-09-10.csv
1acba408185127e6a6ed42d96228c3ce2dbf6759dd5887b77f1f1f493ccd0f2c  sources/spec_attributes_2026-09-10.csv
24db49e05f5e936614da919ec0433b63e6069321bb5fb91aeb7ec26fcbff3dd9  sources/coq_register_2026-09-10.csv
ddf7d46a34a91d0c9ec921778aefa372086c6c53ad9d9ae712cd76a1b8532349  sources/cell_resolution_2026-09-09.tsv
416f495401b92907c25027fdebe5be5636fecae506e458358e4676e4ba76b47e  sources/coverage_update_2026-09-09.tsv
5a918488f038d010c47bdad1c16eb9bc17749aff80795a0fef35602d0068d70b  sources/identity_block_2026-09-09.tsv
d8a2c1df09e3f6599e01fef89be3a38d50d860f3017a94eb74f0a51524ce7a24  sources/coq_draft_scope_2026-09-10.csv
690bb197ce43997a96e8d5c23d23e5f9c90af986e1e8d097b30f9e19e41bab11  sources/coq_draft_gaps.csv
e0e538ab69bb2825d3bfd64df5dce4bed36ce91efe4dfea1133e293058690b67  docs/OPEN_ITEMS.md
548279a2d9a9dc10dc9ab701b15b150ff9373d4a99f4728de864496f66f3b3c9  docs/RESULT_SUPERSESSION_2026-09-16.md
bcedcf32db1396d1b5b23409250a3dfd2b55ca3a0cc900c864dda4db0b264793  tables/Batch_Parameter_Sources_v40.xlsx
7369bf342332ea4093b12a3530a3e0f7fe1e3d936852b5272c1304336e8917d2  tables/Batch_Parameter_Sources_v40.csv
d97e9318b513978e6451f473547aabf99e7f91d013ac3183022263cfeb54f5e7  tables/Batch_Parameter_Sources_v40_long.csv
e9c608f712ab3a463ba22b6a1d3e11581240cd8c4f2d6b3892f4aa28fb67e9e3  docs/COMMUNICATION_CoQ_RELEASE_2026-09-16.md
96555e37373ee61fb01436456369f203b93d8e7eb746280f0e9063b3d3375ec5  docs/FLEET_FINDINGS_2026-09-16.md
f7315cbf159508aaf14c125324313e970fb7d7308364630e0ce9df67a59c3498  docs/HANDOVER_RESPONSE_2026-09-16.md
c11d1a356842123401d6829476dd894ad6dfba1eb53f19a9038eb446c568346e  docs/TRUTH_CHECK_2026-09-15.md
512c8fca43e11b78338c89dad51fc1f9475ec7146022d480ce8929a9fb31e814  docs/VOCABULARY_2026-09-11.md
2f86d9e6ae5800af08077c3a90d659b71e9758cfdd75a59f0511669a2ce2b7e8  docs/ISSUANCE_RULES_2026-09-10.md
101232cbe02dabe959f4ac14e3f9bdd773bfa6ff42bf2172d41b88389a7f157f  docs/COQ_DRAFTING_2026-09-10.md
c1a63066fb0b120ab094c30d9c013b6b0511a9ebc85f2cee59a8bc6af08f7aba  docs/V20_RECONCILIATION_2026-09-10.md
eb5abd63c0a1922d36dc10e9f783a8ca76469d7faea8a35acdb64e0c086d0818  docs/DELIVERY_RECONCILIATION_2026-09-07.md
c05e45cd66d0a9a9b148f12d712e13e302d2532783d27c80e9bcc8dc48956068  docs/drafts_README.md
```
