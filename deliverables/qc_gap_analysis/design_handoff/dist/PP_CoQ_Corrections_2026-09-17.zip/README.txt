The corrections of 17.09.2026 — the certificates that changed
=============================================================

CoQ-PP_26-089  P050212  reissue   #9.1-#9.5 now cite 534/1065/26 of 31.08.2026
                                  TAMC 6,2 x 10^3 · TYMC 2,3 x 10^2 · bile-tolerant < 10^4 and > 10^3
                                  date of issue moved 17.08.2026 -> 07.09.2026
CoQ-PP_26-027  P050212  release   unchanged — it states the release round, where TYMC was
                                  4.9 x 10^4 and out of specification (kept for comparison)

CoQ-PP_26-110  P050222  reissue   #9.1-#9.5 now cite 535/1066/26 of 31.08.2026
                                  TAMC 4,2 x 10^3 · TYMC < 10 · date unchanged (18.09.2026)

CoQ-PP_26-007  P050022  release   #9 now cites 471-0862-25 of 22.05.2025 (TAMC 700, TYMC < 10,
                                  bile-tolerant < 10^2 and > 10) and #10.2/#11/#12 now cite
                                  2471/2025 of 30.05.2025 — heavy metals ALL ND (arsenic was 0.047)

CoQ-PP_26-010  P050042  release   #9 now cites 407-0745-25 of 05.05.2025 (the release page)
                                  instead of 2156/2025 of 07.05.2025

CoQ-PP_26-046  P060102  release   loss on drying 6,8 % from Farmahem 031-3-GS/26 of 12.02.2026
CoQ-PP_26-165  P060102  reissue   the same

P060382 is not here: it has no heavy-metal, pesticide or loss-on-drying report anywhere —
197-21-M/26 was read at full resolution on 17.09.2026 and reports mycotoxins only.
